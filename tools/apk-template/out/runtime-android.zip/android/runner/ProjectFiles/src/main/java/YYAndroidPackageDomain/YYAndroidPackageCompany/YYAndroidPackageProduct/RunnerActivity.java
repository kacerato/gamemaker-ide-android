package ${YYAndroidPackageName};

import androidx.fragment.app.FragmentActivity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.BroadcastReceiver;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.view.InputDevice;
import android.view.WindowManager;
import android.view.Surface;
import android.view.SurfaceView;
import android.bluetooth.BluetoothDevice;
import android.content.IntentFilter;
import android.annotation.TargetApi;
import androidx.core.view.WindowInsetsCompat;
import android.view.DisplayCutout;
import android.view.WindowInsets;
import androidx.core.view.ViewCompat;
import android.graphics.Insets;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Enumeration;
import java.util.Locale;
import java.util.List;
import com.yoyogames.runner.RunnerJNILib;
import android.os.Build;
import android.annotation.SuppressLint;
import android.view.SurfaceHolder;

import org.json.JSONObject;
import org.json.JSONArray;





import org.ini4j.Ini;

//----------------------------------------------------------------------------------------------------
public class RunnerActivity extends AppCompatActivity  implements SensorEventListener, SurfaceHolder.Callback 
{
	// The Singleton for RunnerActivity
	public static RunnerActivity CurrentActivity;

	public static Display CurrentDisplay = null;

	public static AtomicBoolean DisplayUpdatePending = new AtomicBoolean(false);
	public static Display.Mode CurrentDisplayMode = null;

	public static final String BASE64_PUBLIC_KEY = "${YYAndroidGoogleLicensingPublicKey}";
    public static final byte[] SALT = new byte[] { -5, 12, -68, 7, -12, 67, 3, 4, 4, 19, 6, 7, 16, 11, 9, 51, 71, 34, 19, 16 };

	public static int UIVisibilityFlags = 0x1706;

//    public static final int DIALOG_CANNOT_CONNECT_ID = 1;
//    public static final int DIALOG_BILLING_NOT_SUPPORTED_ID = 2;
//    public static final int DIALOG_BILLING_PURCHASE_ERROR = 3;

  //  public static final int SETTINGS_ID = 1;
  //  public static final int EXIT_ID = 2;
    
//	public static RunnerDownloadTask DownloadTask;
//	public static DownloadStatus DownloadTaskStatus;

	public static boolean UseAPKExpansionFile = false;	//APK Expansion file to download
	public static boolean APKExpansionFileReady = false;

	public static boolean UseDynamicAssetDelivery = false;

    public static String InputStringResult;
	public static int  ShowQuestionYesNo; 
	
	public static boolean HasRestarted = false; //for the Player to flag we're re-starting

	
    public static float AccelX;
    public static float AccelY;
    public static float AccelZ;
    public static int Orientation;
    public static int DefaultOrientation;
    public static int ConfigOrientation;
	public static String m_versionName;
    
    public static Handler ViewHandler;// = new Handler();	//unsafe- static initialiser called when class loaded- not guaranteed to be loaded in main thread
    public static int DisplayWidth;
    public static int DisplayHeight;
    public static boolean XPeriaPlay = false;
    
    public static String SaveFilesDir = null;
    public static boolean FocusOverride  = false;  
	public static boolean HasFocus = false;
    
	public static IniBundle mYYPrefs;    
	public static int AllowedOrientationMask = 0xf;    
		
  
	//public static ISocial mSocial;
	public static Object[] mExtension;
  
	public boolean mbAppSuspended = false;
 
	private int maxRefreshRate = 0;
	private int selectedDisplayModeId = 0;
	
    private DemoGLSurfaceView mGLView;
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;

    private static Method mSetSystemUiVisibility = null;
    
    private Handler mHandler = new Handler();

	public Object vsyncHandler = null;

	private RunnerKeyboardController m_keyboardController = null;

	public DemoGLSurfaceView GetGLView(RunnerVsyncHandler.Accessor a)
	{
		a.hashCode();		// only the RunnerVsyncHandler class can call this function (nice 'friend class' trick from here https://stackoverflow.com/questions/182278/is-there-a-way-to-simulate-the-c-friend-concept-in-java)

		return mGLView;
	}
    
    private Runnable mUpdateTimerTask = new Runnable() {
    	public void run() {
    	}
    };
    
    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) 
    {
        // Write your code here
 
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).onKeyLongPress(keyCode,event);
					if(consumed)
						return consumed;	
				}
			}
		}
		
 
        if (keyCode == KeyEvent.KEYCODE_BACK) 
		{
			RunnerJNILib.BackKeyLongPressEvent();
			//Log.i("yoyo", "Long back press!");
        
			return true; //signal that we have consumed this press
		}
		return super.onKeyLongPress(keyCode, event);
    }    
     
   
    
    public boolean isTablet() {
    	try {
    		DisplayMetrics dm = getResources().getDisplayMetrics();
    		float screenWidth = dm.widthPixels / dm.xdpi;
    		float screenHeight = dm.heightPixels / dm.ydpi;
    		double size = Math.sqrt( (screenWidth*screenWidth) + (screenHeight*screenHeight) );
    		return (size >= 6);
    	} catch( Throwable _t ) {
    		Log.i( "yoyo", "Failed to compute screen size" );
    		return false;
    	} // end catch
    } // end isTablet
    
    private boolean mReceiverRegistered = false;
    //The BroadcastReceiver that listens for bluetooth broadcasts
	private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

	//	Log.i("yoyo","BluetoothDevice Receiver for device " + device.getAddress() + " receieved " + action);

        if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
          
          //Log.i("yoyo","Bluetooth device connected");
		  RunnerJNILib.onGamepadChange();
          //Gamepad.EnumerateDevices();	
          //Gamepad.BluetoothDeviceConnected(device);
        }
        else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
         
          //Log.i("yoyo","Bluetooth device disconnected");
		  RunnerJNILib.onGamepadChange();
          //Gamepad.EnumerateDevices();	
          //Gamepad.BluetoothDeviceDisconnected(device);
        }   
    }
	};

	public static Display queryCurrentActivityDisplay(RunnerActivity appActivity)
	{
		try
		{
			final WindowManager windowManager = appActivity.getWindowManager();
			final Display activityDisplay = windowManager.getDefaultDisplay();

			if(activityDisplay != null)
			{
				final int displayPixelFormat = activityDisplay.getPixelFormat();

				if(displayPixelFormat != PixelFormat.UNKNOWN)
				{
					Log.i("yoyo", "Got a display with PixelFormat =  " + displayPixelFormat);

					return activityDisplay;
				}
			}
		}
		catch(Exception e)
		{
			Log.i("yoyo","[queryCurrentActivityDisplay] Error: " + e.getMessage());
		}

		return null;
	}

	public static Display getCurrentActivityDisplay()
	{
		try
		{
			if(CurrentDisplay == null)
			{
				Display activityDisplay = queryCurrentActivityDisplay(CurrentActivity);

				if(activityDisplay != null)
				{
					CurrentDisplay = activityDisplay;
				}
			}
		}
		catch(Exception e)
		{
			Log.i("yoyo","[queryCurrentActivityDisplay] Error: " + e.getMessage());
		}

		return CurrentDisplay;
	}

	@TargetApi(android.os.Build.VERSION_CODES.R)
	private Display.Mode selectClosestDisplayModeForRefreshRate(int requestedRefreshRate)
	{
		try
		{
			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R)
			{
				if(requestedRefreshRate == 0)
				{
					Log.i("yoyo","[selectClosestDisplayModeForRefreshRate] Requested refreshRate 0, replacing with maximum available: " + String.valueOf(RunnerJNILib.mMaxRefreshRateSupported));
					requestedRefreshRate = RunnerJNILib.mMaxRefreshRateSupported;
				}

				//We don't deal with the case where there are two modes with the same refresh rate and different resolutions
				//we should probably pick the one that most closely matches our aspect ratio? 
				//Or possibly better not to be doing this in this way, but expose the available modes to the game developer
				//and allow them to pick

				Display.Mode[] supportedDislayModes = getCurrentActivityDisplay().getSupportedModes();

				int refreshRateMinDelta = 999;
				Display.Mode selectedDisplayMode = null;

				Display.Mode highestRefreshDisplayMode = null;
				int highestrefreshspeed =0;

				for (Display.Mode mode : supportedDislayModes)
				{
					int modeRefreshRate = Math.round(mode.getRefreshRate());
					Log.i("yoyo","Available refresh rate: " + modeRefreshRate + " width:"+mode.getPhysicalWidth()+ " by "+mode.getPhysicalHeight());
					// Consider only exact match or higher refresh rate. Setting a mode with lower
					// vsync interval would mean missing vblanks and terrible visual experience.
					if(modeRefreshRate >= requestedRefreshRate)
					{
						int delta = modeRefreshRate - requestedRefreshRate;
						if(delta < refreshRateMinDelta)
						{
							refreshRateMinDelta = delta;
							selectedDisplayMode = mode;
							Log.i("yoyo","Found matching mode with refresh rate: " + String.valueOf(modeRefreshRate));
						}
					}

					if(modeRefreshRate>highestrefreshspeed)
					{
						highestrefreshspeed = modeRefreshRate;
						highestRefreshDisplayMode = mode;

					}

				}

				if(refreshRateMinDelta!=0)
				{
					//Check if it's a multiple of the requested rate so requested 30 would find 60 rather than 120 etc

					int divtest = Math.round(selectedDisplayMode.getRefreshRate()) % requestedRefreshRate;

					if(divtest ==0)
											return selectedDisplayMode;

					//Ok we didn't find a mode that matches exactly so let's just set it to the fastest we have
					return highestRefreshDisplayMode;
				}

				return selectedDisplayMode;
			}
			
		}
		catch(Exception e)
		{
			Log.i("yoyo","[selectClosestDisplayModeForRefreshRate] Error: " + e.getMessage());
		}
		return null;
	}
	@TargetApi(android.os.Build.VERSION_CODES.P)
	public void GenerateAsyncEventForInsets()
	{

	try{
			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P)
			{
				WindowInsets insets = getWindow().getDecorView().getRootWindowInsets();

				if(insets!=null)
				{
					JSONArray list = new JSONArray();
			
					DisplayCutout cut = insets.getDisplayCutout();


					if(cut!=null)
					{
						int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
						RunnerJNILib.DsMapAddString(dsMapIndex, "type", "DisplayLayoutInfo");


						RunnerJNILib.DsMapAddDouble(dsMapIndex, "safeinsetbottom", (double)cut.getSafeInsetBottom() );
						RunnerJNILib.DsMapAddDouble(dsMapIndex, "safeinsettop", (double)cut.getSafeInsetTop() );
						RunnerJNILib.DsMapAddDouble(dsMapIndex, "safeinsetleft", (double)cut.getSafeInsetLeft() );
						RunnerJNILib.DsMapAddDouble(dsMapIndex, "safeinsetright", (double)cut.getSafeInsetRight() );

						if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R)
						{
							Insets ins = cut.getWaterfallInsets();
							RunnerJNILib.DsMapAddDouble(dsMapIndex, "waterfallinsetbottom", (double)ins.bottom);
							RunnerJNILib.DsMapAddDouble(dsMapIndex, "waterfallinsettop", (double)ins.top );
							RunnerJNILib.DsMapAddDouble(dsMapIndex, "waterfallinsetleft", (double)ins.left );
							RunnerJNILib.DsMapAddDouble(dsMapIndex, "waterfallinsetright", (double)ins.right );
						}

						List<Rect> cuts = cut.getBoundingRects();
						for (Rect c : cuts ) {
							JSONObject map = new JSONObject();
							map.put("left",c.left);
							map.put("right",c.right);
							map.put("top",c.top);
							map.put("bottom",c.bottom);
//							Log.i("yoyo","cutrect :" +c.toString());
							list.put(map);
						}
						RunnerJNILib.DsMapAddString(dsMapIndex, "boundrects", list.toString() );
						RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex, EVENT_OTHER_SYSTEM_EVENT);
					}
					else
						Log.i("yoyo","Failed to find display cutout");

				}
			}
		}
		catch(Exception e)
		{
		}
	}

	public void updateDisplayModeForRefreshRate(int refreshRate)
	{
		

		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R)
		{
			try
			{
				if(RunnerActivity.DisplayUpdatePending.get())
				{
					Log.i("yoyo","[updateDisplayModeForRefreshRate] Error: request discarded, another update is pending already.");
					return;
				}

					Display.Mode selectedMode = selectClosestDisplayModeForRefreshRate(refreshRate);
					if(selectedMode == null)
					{
						Log.i("yoyo","[updateDisplayModeForRefreshRate] Error: could not find supported DM for requested rate: " + String.valueOf(refreshRate));
						RunnerActivity.DisplayUpdatePending.set(false);
						return;
					}

					if(selectedMode != null)
					{
						RunnerActivity.DisplayUpdatePending.set(true);
						Looper mainThreadLooper = Looper.getMainLooper();

						// Check if the access is allowed.
						if(mainThreadLooper != null)
						{
							CurrentActivity.runOnUiThread(new Runnable()
							{
								@Override
								public void run()
								{
									Window activityWindow = CurrentActivity.getWindow();
									WindowManager.LayoutParams layoutParams = activityWindow.getAttributes();

									layoutParams.preferredDisplayModeId = selectedMode.getModeId();
									activityWindow.setAttributes(layoutParams);

									RunnerJNILib.mCurrentRefreshRate = Math.round(selectedMode.getRefreshRate());
									RunnerJNILib.OnDisplayFrequencyChanged();
                
									RunnerActivity.CurrentDisplayMode = selectedMode;
									RunnerActivity.DisplayUpdatePending.set(false);

								Log.i("yoyo", "Selected activity refresh rate: " + String.valueOf(RunnerJNILib.mCurrentRefreshRate));
							}
						});
					}
				}
				else
				{
					Log.i("yoyo","[updateDisplayModeForRefreshRate] Error: could not find a matching mode for refreshRate = " + String.valueOf(refreshRate));
				}
			}
			catch(Exception e)
			{
				Log.i("yoyo","[updateDisplayModeForRefreshRate] Error: " + e.getMessage());
			}
		}
	}

	@TargetApi(30)
	private void FindMaxRefreshRate()
	{
		try
		{
			Display.Mode[] supportedDislayModes = getDisplay().getSupportedModes();

			for (Display.Mode mode : supportedDislayModes)
			{
				int refreshRate = Math.round(mode.getRefreshRate());

				// For initial run, select the highest available refresh rate. This is a good
				// way to enable higher RRs on modern devices (> 60Hz). We'll control that using
				// our FPS timer anyway.
				if(refreshRate > maxRefreshRate)
				{
					maxRefreshRate = refreshRate;
					selectedDisplayModeId = mode.getModeId();
				}
			}

			Window activityWindow = CurrentActivity.getWindow();
			WindowManager.LayoutParams layoutParams = activityWindow.getAttributes();

			layoutParams.preferredDisplayModeId = selectedDisplayModeId;
			activityWindow.setAttributes(layoutParams);
		}
		catch(Exception e) 
		{
			Log.i("yoyo","[Display Frame Rate] Error: " + e.getMessage());
		}
	}
	@TargetApi(34)
	private String SetEdgeToEdge()
	{
		Bundle bundle = null;

		String _DisplayLayout = null;
		try{
			ApplicationInfo ai = getPackageManager().getApplicationInfo(this.getComponentName().getPackageName(), PackageManager.GET_META_DATA);


			bundle = ai.metaData;

			Boolean edgetoedge = bundle.getBoolean("YYEdgeToEdgeDisplay",false);

			_DisplayLayout = bundle.getString("YYDisplayLayout"); 


			if(edgetoedge)
			{
				Log.i("yoyo","Enabling edgetoedge");

				EdgeToEdge.enable(this);
			}
			else
				Log.i("yoyo","edgetoedge is not set");
		}
		catch( Exception _e ) 
		{
			Log.d( "yoyo", "Exception while reading package meta data" +_e.toString() );
		} // end catch   	 

		return _DisplayLayout;
	}



	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
		this.requestWindowFeature( Window.FEATURE_NO_TITLE );
		
    	ViewHandler = new Handler();
    	Log.i("yoyo", "onCreate");
        super.onCreate(savedInstanceState);
        
		String _DisplayLayout = null;


		if (Build.VERSION.SDK_INT >= 34)
			_DisplayLayout = SetEdgeToEdge();

		ViewCompat.setOnApplyWindowInsetsListener(this.getWindow().getDecorView(), (v, insets) -> {

			this.GenerateAsyncEventForInsets();

			return ViewCompat.onApplyWindowInsets(v, insets);
		});


		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        if (_DisplayLayout != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
			Log.i("yoyo","_DisplayLayout is "+_DisplayLayout);
			if(_DisplayLayout.equals("LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT"))
				getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
			else if(_DisplayLayout.equals("LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS"))
				getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
			else if(_DisplayLayout.equals("LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES"))
				getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
			else if(_DisplayLayout.equals("LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER"))
				getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
			else
			{
				Log.i("yoyo","layoutInDisplayCutoutMode passed unknown option");
			}
        }

		Window activityWindow = getWindow();
		WindowManager.LayoutParams layoutParams = activityWindow.getAttributes();


									

		//layoutParams.setFitInsetsSides(0);
		activityWindow.setAttributes(layoutParams);
		Log.i("yoyo","Found attributes1:"+layoutParams.toString());

       
		RunnerJNILib.Init( this );
               
        checkIsYoYoRunner();		
	      

		try
		{
			m_versionName = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
		}
		catch (NameNotFoundException e)
		{
			m_versionName = "1.0.xxx";
			Log.v("yoyo", e.getMessage());
		}
		RunnerJNILib.ms_versionName = m_versionName;
        Log.i( "yoyo", "###@@@@!!!~~~~###### versionName - " + m_versionName);

		// set the current orientation
		switch( getResources().getConfiguration().orientation ) {
		default:
		case Configuration.ORIENTATION_LANDSCAPE:
		case Configuration.ORIENTATION_SQUARE:
			Orientation = 0;
			break;
		case Configuration.ORIENTATION_PORTRAIT:
			Orientation = 1;
			break;
		case Configuration.ORIENTATION_UNDEFINED:
			Orientation = 1;
			break;
		} // end switch
        
        // Grab singleton
        CurrentActivity = this;
        
        // Grab the display settings for the game
    	Display display = getWindowManager().getDefaultDisplay();
    	DisplayWidth = display.getWidth();
    	DisplayHeight = display.getHeight();

       // this.requestWindowFeature( Window.FEATURE_ACTION_BAR);

		// Grab the sensor manager and accelerometer        
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER); 
		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME);
        
        DefaultOrientation  = getDeviceDefaultOrientation();
        Log.i( "yoyo", "###@@@@!!!~~~~###### default orientation - " + DefaultOrientation);
        
        setupIniFile();
        //Moved this here as we need to initialise the extensions before checking for apk expansion...
        setupExtensions();
        
        
        
        
        // Setup the various things needed
        checkXPeriaPlay();
        //checkLicensing();
        
        RunnerJNILib.CallExtensionFunction("GooglePlayLicensingAsExt","checkLicensing",0,null);
        
        //setupView();	
       
        
        //start APK expansion download if required
        Log.i( "yoyo", "!!!!!!! Checking if APK Expansion file required...");
        boolean bDownloadView = false;
		if( UseAPKExpansionFile )
		{
			Object downloadViewNeeded = RunnerJNILib.CallExtensionFunction("PlayAPKExpansionExtension","StartAPKExpansionDownload",0,null);
			if(downloadViewNeeded!=null)
			{
				bDownloadView = (Boolean)downloadViewNeeded;
			}
			
			//bDownloadView = StartAPKExpansionDownload();
		}	
		if(bDownloadView && !HasRestarted) 
		{
			//setupDownloadView();
			RunnerJNILib.CallExtensionFunction("PlayAPKExpansionExtension","setupDownloadView",0,null);
		}	
		else 
		{
			setupView();	
		}
		
		if(mYYPrefs!=null)
		{
			if(mYYPrefs.getBoolean("YYiCadeSupport"))
			{		
				Log.i("yoyo","Registering receiver to receive bluetooth device connection messages");
				IntentFilter filter1 = new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED);
				filter1.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
				Intent intent = this.registerReceiver(mReceiver, filter1);
				if(intent!=null)
					mReceiverRegistered = true;
			}
			else
				Log.i("yoyo","Option not set so not connecting receiver");
				
		}
		else
			Log.i("yoyo","No prefs set so not connecting receiver");
			

		//if(checkCallingOrSelfPermission("android.permission.BLUETOOTH")== PackageManager.PERMISSION_GRANTED)
		//{
			
		//}
		
		if (android.os.Build.VERSION.SDK_INT >= 19 /*android.os.Build.VERSION_CODES.KITKAT*/)
		{
		 final View decorView = getWindow().getDecorView();
            decorView.setOnSystemUiVisibilityChangeListener (new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) 
            {
				//Log.i("yoyo","onSystemUiVisibilityChange called with "+ visibility);
				setupUiVisibility();
    			setupUiVisibilityDelayed();
    			
            }
        });
		}


		Log.i( "yoyo", "!!!!!!! Using frame count timing if possible...");
		vsyncHandler = new RunnerVsyncHandler();
		((RunnerVsyncHandler)vsyncHandler).PostFrameCallback();
		

		// Initialise virtual keyboard controller
		RunnerKeyboardController keyboardController = GetKeyboardController();
		if(keyboardController != null)
		{
			// Update initial physical keyboard status
			boolean physicalKeyboardConnected = (getResources().getConfiguration().hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_NO ? true : false);
			keyboardController.SetPhysicalKeyboardConnected(physicalKeyboardConnected);
		}




		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R)
		{
			FindMaxRefreshRate();
			
		}
		else
		{
			maxRefreshRate = 60;
			selectedDisplayModeId = 0;
		}

		RunnerJNILib.mMaxRefreshRateSupported = maxRefreshRate;
		RunnerJNILib.mGameSpeedControl = 60; //This is what the runner defaults to
		RunnerJNILib.mCurrentRefreshRate = maxRefreshRate;

		Log.i("yoyo","[Display Frame Rate] Selected DisplayMode: " + String.valueOf(selectedDisplayModeId));
		Log.i("yoyo","[Display Frame Rate] Maximum reported refresh rate: " + String.valueOf(maxRefreshRate));



	}

	public void setupIniFile()
	{
    	String packageName = this.getComponentName().getPackageName();
    	Log.i( "yoyo", "#####!!!! package name is " + packageName );

		// Just use manifest file if this is a package
		Log.i("yoyo", "Loading INI from manifest file" );
		Bundle bundle = null;
		try {
			ApplicationInfo ai = getPackageManager().getApplicationInfo(this.getComponentName().getPackageName(), PackageManager.GET_META_DATA);
			bundle = ai.metaData;   
					
		} catch( Exception _e ) {
			Log.d( "yoyo", "Exception while setting up Ini" +_e.toString() );
		} // end catch

		mYYPrefs = new IniBundle( bundle, null , "Android");
		Log.i("yoyo", "INI loaded from AndroidManifest.xml" );
	}

	public void doSetup( String _zipName )
	{
		Log.d( "yoyo", "doSetup called - " + _zipName );
	    
	    setupExtensions();
      
		Gamepad.Initialise();
		//Gamepad.EnumerateDevices();
		
		RestrictOrientation(false,false,false,false,true);

		DemoRenderer.m_state = DemoRenderer.eState.WaitOnTimer;
	} // end doSetup

	


    
    public void RestrictOrientation(boolean _landscape,boolean _portrait,boolean _landscapeFlipped,boolean _portraitFlipped,boolean _fromPrefs ) 
	{
		if(_fromPrefs)
		{
    		_landscape = false;
    		_portrait = false;
    		_landscapeFlipped = false;
    		_portraitFlipped = false;
    		
    		if( mYYPrefs != null  )
    		{
    			Log.i( "yoyo", "RestrictOrientation setting from YYPrefs");	//remove me
    			_landscape = ( mYYPrefs.getInt("OrientLandscape") != 0 );
    			_portrait = ( mYYPrefs.getInt("OrientPortrait") != 0 );
    			_landscapeFlipped = ( mYYPrefs.getInt("OrientLandscapeFlipped") !=0 );
    			_portraitFlipped = ( mYYPrefs.getInt("OrientPortraitFlipped") !=0 );
    		}
    	}
    	
    
		Log.i( "yoyo", "RestrictOrientation(\"" +_landscape+ "\", \""+_portrait+"\""+_landscapeFlipped+"\""+_portraitFlipped+"\")");
    	
		AllowedOrientationMask = (_landscape ? 1 : 0) | (_portrait ? 2 : 0) | (_landscapeFlipped ? 4 : 0) | (_portraitFlipped ? 8 : 0);
    	
    	
    	if (_landscape && !_portrait && !_landscapeFlipped && !_portraitFlipped) {
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE );
    	} // end if
    	else
    	if (!_landscape && _portrait && !_landscapeFlipped && !_portraitFlipped) {
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_PORTRAIT );
    	} // end if
    	else
    	if (!_landscape && !_portrait && _landscapeFlipped && !_portraitFlipped) {
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE );
    	} // end if
    	else
    	if (!_landscape && !_portrait && !_landscapeFlipped && _portraitFlipped) {
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT );
    	} // end if
    	else
    	if  ((_landscape && !_portrait && _landscapeFlipped && !_portraitFlipped) || 
    		 (_landscape && _portrait && _landscapeFlipped && !_portraitFlipped) || 
    		 (_landscape && !_portrait && _landscapeFlipped && _portraitFlipped)
    		){
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE );
    	} // end if
    	else
    	if ((!_landscape && _portrait && !_landscapeFlipped && _portraitFlipped) ||
    		(_landscape && _portrait && !_landscapeFlipped && _portraitFlipped) ||
    		(!_landscape && _portrait && _landscapeFlipped && _portraitFlipped)
    		){
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT );
    	} // end if
    	else {
    		setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED );
    	} // end else
	} // end RestrictOrientation
    
    /* 
     * Called when the activity is being started up 
     */
    @Override
    protected void onStart() {    

    	Log.i("yoyo", "onStart");
        super.onStart();
                
        // registerUnlockReceiver();
        
        //if (Flurry) {
	    //    Log.i( "yoyo", "@@@@@@@ Flurry session started code = " + FlurryCode);
		//	FlurryAgent.setReportLocation(false);
		//	FlurryAgent.setLogEvents(true);
        //	FlurryAgent.onStartSession( this, FlurryCode );
        //} // end if
		//if(mbGoogleAnalytics)
		//{
		//	mGaTracker.sendView("/GameStart");
		//}
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
  			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
					((IExtensionBase)RunnerActivity.mExtension[i]).onStart();
				//if(RunnerActivity.mExtension[i] instanceof ISocial )
				//	((ISocial)RunnerActivity.mExtension[i]).onStart();
				//else if(RunnerActivity.mExtension[i] instanceof IAdExt)
				//	((IAdExt)RunnerActivity.mExtension[i]).onStart();
			}
		}

    }
    
    @Override
    protected void onRestart()
    {
		Log.i("yoyo","onRestart");
		super.onRestart();
		
		if (RunnerActivity.mExtension != null) {
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
  			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
					((IExtensionBase)RunnerActivity.mExtension[i]).onRestart();
				//if(RunnerActivity.mExtension[i] instanceof ISocial)
				//	((ISocial)RunnerActivity.mExtension[i]).onRestart();
				//else if(RunnerActivity.mExtension[i] instanceof IAdExt)
				//		((IAdExt)RunnerActivity.mExtension[i]).onRestart();
			}
		} // end if
    }
    
    /**
     * Called when this activity is no longer visible.
     */
    @Override
    protected void onStop() {
    
    	Log.i("yoyo", "onStop");
    
    	 
    	
        super.onStop();		
        
		// Not doing this now as onStop() occurs when going off to the Market app and we need to
		// still be listening for a response from the market even whilst stopped or it may send its
		// response before our application has been fully reawoken
        // if (checkCallingOrSelfPermission("com.android.vending.BILLING")==0) {        	
	    //     RunnerBillingResponseHandler.unregister(mBillingPurchaseObserver);	        	        
	    // } 
	    
        //if (Flurry) {
	    //    Log.i( "yoyo", "@@@@@@@ Flurry session stopped code = " + FlurryCode);
        //	FlurryAgent.onEndSession( this );
        //} // end if
        //if(mbGoogleAnalytics)
		//{
		//	// We send an empty event so we get accurate time-on-page/site info.
		//	mGaTracker.sendEvent("", "", "", null);
		//	//do a manual dispatch to make sure all events are sent...
		//	GAServiceManager.getInstance().dispatch();
		//}
		
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
  			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
					((IExtensionBase)RunnerActivity.mExtension[i]).onStop();
				//if(RunnerActivity.mExtension[i] instanceof ISocial)
				//	((ISocial)RunnerActivity.mExtension[i]).onStop();
				//else if(RunnerActivity.mExtension[i] instanceof IAdExt)
				//	((IAdExt)RunnerActivity.mExtension[i]).onStop();
			}
		}

		// Hide virtual keyboard if it's been shown
		if(m_keyboardController != null && m_keyboardController.GetVirtualKeyboardVisible() == true)
		{
			m_keyboardController.VirtualKeyboardHide();
		}
    }
    
    
    /**
     * Called when this activity is being destroyed
     */
    @Override
    protected void onDestroy() {
    
    	Log.i("yoyo", "onDestroy");
        super.onDestroy();
        
	    
	   
	    if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
  			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
					((IExtensionBase)RunnerActivity.mExtension[i]).onDestroy();
				
			}
		}

		// Hide virtual keyboard if it's been shown
		if(m_keyboardController != null && m_keyboardController.GetVirtualKeyboardVisible() == true)
		{
			m_keyboardController.VirtualKeyboardHide();
		}
	 	
		if(mYYPrefs!=null)
		{
			if(mYYPrefs.getBoolean("YYiCadeSupport"))
			{		
				if(mReceiverRegistered)
				{
					Log.i("yoyo","Unregistering receiver");
					try
					{this.unregisterReceiver(mReceiver);}
					catch(Exception e)
					{Log.i("yoyo","UnregisterReceiver Error: " + e.toString());}
					mReceiverRegistered = false;
				}
			}
		}

		

		Log.i("yoyo", "About to attempt kill of process in onDestroy::"+Process.myPid());
		Process.killProcess( Process.myPid() ); 
			
	    // Kill the activity completely!
	    java.lang.System.exit(0);
		
    }

	public void onNewIntent(android.content.Intent newIntent) {

		super.onNewIntent(newIntent);
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					((IExtensionBase)RunnerActivity.mExtension[i]).onNewIntent(newIntent);	
				}
			}
		}
	}
	protected void resumeApp()
	{

		
	
	}
    
  
    
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
    		
    	Log.i("yoyo", "onWindowFocusChanged(" + hasFocus + "|" + FocusOverride + ")");
	    super.onWindowFocusChanged(hasFocus);
	
		if (RunnerJNILib.ms_exitcalled) {
			Log.i("yoyo","Ignoring focus change as we are exiting");
			return;
		}
	
		HasFocus = (hasFocus|FocusOverride);
    	FocusOverride = false;
		
		
		setupUiVisibility();
    	setupUiVisibilityDelayed();
    	
		

    	if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					((IExtensionBase)RunnerActivity.mExtension[i]).onWindowFocusChanged(hasFocus);
				}
			}
		}
		
    }
    
    @Override
    protected void onPause() {		

		Log.i("yoyo", "onPause");
		super.onPause();

		if(!mbAppSuspended)
		{
			mbAppSuspended = true;	//prevent multiple resumeApp()
			RunnerJNILib.mVideoPlayback.onPause();

    		mSensorManager.unregisterListener(this);
    	
    		Log.i("yoyo", "Pausing the Runner");
			if (!RunnerJNILib.ms_loadLibraryFailed) {
				RunnerJNILib.Pause(0);
			} // end if

			if(mYYPrefs!=null)
			{
				if(mYYPrefs.getBoolean("YYiCadeSupport"))
				{		
					if(mReceiverRegistered)
					{
						Log.i("yoyo","Unregistering receiver");
						try
						{this.unregisterReceiver(mReceiver);}
						catch(Exception e)
						{Log.i("yoyo","UnregisterReceiver Error: " + e.toString());}
						mReceiverRegistered = false;
					}
				}
			}
       
       
			if (mGLView != null && mGLView.mRenderer!=null) {
				mGLView.onPause();
				mGLView.mRenderer.m_pauseRunner = true;
			}
		

			if(RunnerActivity.mExtension!=null)
			{
				for(int i=0;i<RunnerActivity.mExtension.length;i++)
  				{	 
					if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
						((IExtensionBase)RunnerActivity.mExtension[i]).onPause();
					//if(RunnerActivity.mExtension[i] instanceof ISocial)
					//	((ISocial)RunnerActivity.mExtension[i]).onPause();
					//else if(RunnerActivity.mExtension[i] instanceof IAdExt)
					//	((IAdExt)RunnerActivity.mExtension[i]).onPause();
				}
			}
		
			DemoRenderer.elapsedVsyncs = -1;

			if (vsyncHandler != null)
			{
				((RunnerVsyncHandler)vsyncHandler).RemoveFrameCallback();
			}

			// Hide virtual keyboard if it's been shown
			if(m_keyboardController != null && m_keyboardController.GetVirtualKeyboardVisible() == true)
			{
				m_keyboardController.VirtualKeyboardHide();
			}
		}
		else
			Log.i("yoyo", "onPause - ignored due to already being paused");
	}
   
   
    @Override
    protected void onResume() {

		// As per https://developer.nvidia.com/sites/default/files/akamai/mobile/docs/android_lifecycle_app_note.pdf:
		// onResume technically means the start of the "foreground" lifespan of the app, but it does not mean that
		// the app is fully visible and should be rendering, so game updating/rendering does not occur here
		Log.i("yoyo", "onResume");
    	
    	super.onResume();		


		if(mbAppSuspended)
		{
			mbAppSuspended = false;
			RunnerJNILib.mVideoPlayback.onResume();
		
			setupUiVisibility();
    		setupUiVisibilityDelayed();
    	
			int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
			RunnerJNILib.DsMapAddString(dsMapIndex, "event_type", "onResume");
			RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex, 75);//EVENT_OTHER_SYSTEM
			

			if ((RunnerJNILib.ms_context != null) && !RunnerJNILib.ms_loadLibraryFailed)
			{					
				Log.i("yoyo", "Resuming the C++ Runner/resetting GL state");
				RunnerJNILib.Resume(0);
			}	

			if(mYYPrefs!=null)
			{
				if(mYYPrefs.getBoolean("YYiCadeSupport"))
				{		
					Log.i("yoyo","Registering receiver to receive bluetooth device connection messages");
					IntentFilter filter1 = new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED);
					filter1.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
					this.registerReceiver(mReceiver, filter1);
				}			
			}


			if (RunnerJNILib.ms_context != null) 
			{		
				RunnerJNILib.onGamepadChange();
			}
			
			mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME);
			
			if (vsyncHandler != null)
			{
				//Log.i("yoyo", "onResume: postFrameCallback");
				((RunnerVsyncHandler)vsyncHandler).PostFrameCallback();
				//Log.i("yoyo", "onResume: after postFrameCallback");	
			}
		
			//Release mouse taps
			for(int i = 0 ; i < 10 ; i ++)
				RunnerJNILib.TouchEvent( 1, i, -9999999, -9999999, 1);

			if(mGLView!=null && mGLView.mRenderer!=null)
			{
				if (mGLView.mRenderer.m_pauseRunner == true)
				{
					Log.i("yoyo", "resumeApp");
						
					mGLView.onResume();
					// Unblock onDrawFrame() that causes the runner to process
					mGLView.mRenderer.m_pauseRunner = false;
				}
			}
		}
		else
			Log.i("yoyo","onResume ignored due to not being paused");
		
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
					((IExtensionBase)RunnerActivity.mExtension[i]).onResume();

			}
		}
	}		
    
    @Override
    public boolean onCreateOptionsMenu( Menu menu )
    {
    	super.onCreateOptionsMenu( menu );
    	
    	if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).onCreateOptionsMenu(menu);
					if(consumed)
						return consumed;	
				}
			}
		} 	
    	
    	
    	return false;
    }
    
    @Override
    public boolean onOptionsItemSelected( MenuItem item )
    {
    
    	if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).onOptionsItemSelected(item);
					if(consumed)
						return consumed;	
				}
			}
		} 	
    
    
    	switch( item.getItemId() ) {
	//	case SETTINGS_ID: 
		//	Intent settingsActivity = new Intent( getBaseContext(), RunnerPreferenceActivity.class );
			//startActivity( settingsActivity );
			//break;
	//	case EXIT_ID:
    	//	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    		//builder.setMessage( "Are you sure you want to exit?")
    			//.setCancelable(false)
    			//.setPositiveButton( "Yes", new DialogInterface.OnClickListener() {
    				//public void onClick( DialogInterface dialog, int id ) {
    			//		RunnerJNILib.ExitApplication();
    			//	}
     		//	})
    		//	.setNegativeButton( "No", new DialogInterface.OnClickListener() {
    		//		public void onClick( DialogInterface dialog, int id ) {
    		//			dialog.cancel();    					
    		//		}
    		//	});
    		//AlertDialog alert  = builder.create();
    		//alert.show();
			//break;
    	} // end switch
    	
    	return true;
    } // end onOptionsItemSelected
    
    @Override
    public boolean onKeyDown( int keyCode, KeyEvent event ) 
	{
		int eventSource = event.getSource();
		boolean eventFromPhysicalDevice = (event.getDeviceId() > 0);
		boolean eventFromKeyboard = ((eventSource & InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD);
		boolean eventFromGamepad = ((eventSource & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD);
		boolean eventFromJoystick = ((eventSource & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK);
		//Log.i("yoyo", "onKeyDown " + keyCode + " - " + event.getUnicodeChar() + ". Device ID: " + event.getDeviceId() + ". Source: "+eventSource+". Physical: "+eventFromPhysicalDevice+". Keyboard: "+ eventFromKeyboard + ". Gamepad: "+eventFromGamepad);

		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).onKeyDown(keyCode,event);
					if(consumed)
						return consumed;	
				}
			}
		} 	

		// Handle physical keyboard events
		if(eventFromPhysicalDevice && eventFromKeyboard && !eventFromGamepad && !eventFromJoystick)
		{
			//Log.i("yoyo", "[VK] Physical keyboard event detected.");
			RunnerKeyboardController keyboardController = GetKeyboardController();
			if(keyboardController != null)
			{
				keyboardController.OnPhysicalKeyboardKeyEvent(keyCode, event);
			}
		}

    	// record the key events ready to be passed down to the game	
    	if (keyCode != 0 && !eventFromGamepad && !eventFromJoystick) 
		{
			RunnerJNILib.KeyEvent(0, keyCode, event.getUnicodeChar(), eventSource, event.getRepeatCount());

			/* If the virtual keyboard is enabled and backspace is pressed on a PHYSICAL keyboard,
			 * then onKeyUp() isn't called when the backspace key is released, so synthesise an
			 * immediate key release here, otherwise VK_BACK is left latched down in the runner.
			 *
			 * If backspace is pressed on the virtual keyboard its fine, if backspace is pressed on
			 * a physical keyboard while the virtual keyboard is disabled, its fine, if backspace
			 * is pressed on a physical keyboard while the virtual keyboard is enabled then
			 * CAUSALITY IS LOST. EXISTENCE BECOMES AN ENDLESS TURMOIL WHERE THE STATE OF THE
			 * BACKSPACE KEY IS HOTLY DEBATED BY PHILOSOPHERS BUT CAN NEVER TRULY BE KNOWN.
			 *
			 * This hack kinda sucks, since holding backspace down will manifest as it toggling on
			 * and then off every other frame instead, however probably okay as this path will only
			 * be reached when the game has requested the virtual keyboard be enabled for text
			 * input - a game using a physical keyboard for input in a manner where the key state
			 * is polled will *probably* have the virtual keyboard disabled since it kind of sucks
			 * for that anyway...
			*/
			RunnerKeyboardController keyboardController = GetKeyboardController();
			if(keyCode == KeyEvent.KEYCODE_DEL && keyboardController.GetVirtualKeyboardActive())
			{
				RunnerJNILib.KeyEvent(1, keyCode, event.getUnicodeChar(), eventSource, 0);
			}
		}

    	if(keyCode == KeyEvent.KEYCODE_BACK)
    	{
    		//Log.i("yoyo","Started tracking back key");
    		event.startTracking();
			return true;
        }
    	
    	if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP) || 
    		(keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) || 
    		(keyCode == KeyEvent.KEYCODE_HOME) || 
    		(keyCode == KeyEvent.KEYCODE_MENU) ||
    		(keyCode >= KeyEvent.KEYCODE_HEADSETHOOK))
    		{
				setupUiVisibility();
    			setupUiVisibilityDelayed();
	  			return super.onKeyDown(keyCode, event);  	
	  		}
	  	else
		{
	    	return true;
		}
    }
    
    @Override
    public boolean onKeyUp( int keyCode, KeyEvent event ) 
    {
		int eventSource = event.getSource();
		boolean eventFromGamepad = ((eventSource & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD);
		boolean eventFromJoystick = ((eventSource & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK);
		
		//Log.i("yoyo", "onKeyUp " + keyCode + " - " + event.getUnicodeChar());
		
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).onKeyUp(keyCode,event);
					if(consumed)
						return consumed;	
				}
			}
		} 	

		if (!eventFromGamepad && !eventFromJoystick)
		{
    		RunnerJNILib.KeyEvent( 1, keyCode, event.getUnicodeChar(), event.getSource(), 0);
		}

    	if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP) || 
    		(keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)|| 
    		(keyCode == KeyEvent.KEYCODE_HOME)|| 
    		(keyCode == KeyEvent.KEYCODE_MENU)||
    		(keyCode >= KeyEvent.KEYCODE_HEADSETHOOK))
	  		return super.onKeyUp(keyCode, event );  	
	  	else
	    	return true;
    } 

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}
	
	public int getDeviceDefaultOrientation(){

		try {
			Class<?> displayClass = Class.forName("android.view.Display");

			// API level 8
			Method getRotationMethod = displayClass.getDeclaredMethod("getRotation");
			if (getRotationMethod != null) { 						
				WindowManager lWindowManager =  (WindowManager) getSystemService(WINDOW_SERVICE);

				Configuration cfg = getResources().getConfiguration();
				int lRotation = lWindowManager.getDefaultDisplay().getRotation();

				if( (((lRotation == Surface.ROTATION_0) ||(lRotation == Surface.ROTATION_180)) &&   
						(cfg.orientation == Configuration.ORIENTATION_LANDSCAPE)) ||
						(((lRotation == Surface.ROTATION_90) ||(lRotation == Surface.ROTATION_270)) &&    
						(cfg.orientation == Configuration.ORIENTATION_PORTRAIT))){
					return Configuration.ORIENTATION_LANDSCAPE;
				}
			} // end if
		}
		catch (Exception e) {
			Log.i("yoyo", "ERROR: Enumerating API level " + e.getMessage());
		}
		return Configuration.ORIENTATION_PORTRAIT;
	}

	@Override
	public void onSensorChanged(SensorEvent event) {			
		switch( DefaultOrientation ) {
		default:
		case Configuration.ORIENTATION_PORTRAIT:
			AccelX = event.values[0] / 9.80665f;
			AccelY = event.values[1] / 9.80665f;
			AccelZ = event.values[2] / 9.80665f;
			break;
		case Configuration.ORIENTATION_LANDSCAPE:
			AccelX = event.values[1] / 9.80665f;
			AccelY = -event.values[0] / 9.80665f;
			AccelZ = event.values[2] / 9.80665f;
			break;				
		} // end switch
	}
	
	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    
    	Log.i("yoyo", "Got activity result: " + resultCode);
    	
    	
		super.onActivityResult(requestCode, resultCode, data);
		
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
  			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
					((IExtensionBase)RunnerActivity.mExtension[i]).onActivityResult(requestCode,resultCode,data);
			}
		}
			
		
		
		
		setupUiVisibility();
    	setupUiVisibilityDelayed();
    	
		
		Log.i("yoyo", "End Got activity result");
		
		
		
    } 
    
	int EVENT_OTHER_SYSTEM_EVENT = 75;
	
	
    @Override
	public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) 
	{
		if (RunnerJNILib.s_MicPermReqMap.containsKey(requestCode)) {
			RunnerJNILib.ProcessMicPermReqResult(requestCode, permissions, grantResults);
			return;
		}

		Log.i("yoyo","onRequestPermissionsResult " +requestCode+ " returned with: " + permissions.toString() + " results:" +grantResults.toString());
		
		
		int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
		RunnerJNILib.DsMapAddString( dsMapIndex, "type", "permission_request_result" );
		for(int i=0;i<grantResults.length;i++)
			RunnerJNILib.DsMapAddDouble( dsMapIndex,permissions[i] ,(double)(grantResults[i] == 0 ? 1 : 0));
	
		RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex,EVENT_OTHER_SYSTEM_EVENT);
		
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					((IExtensionBase)RunnerActivity.mExtension[i]).onRequestPermissionsResult(requestCode,permissions,grantResults);
					
				}
			}
		}
    
		super.onRequestPermissionsResult(requestCode,permissions,grantResults);
		
	}
     
    @Override
    protected Dialog onCreateDialog(int id) 
    {
    
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					Dialog consumed =((IExtensionBase)RunnerActivity.mExtension[i]).onCreateDialog(id);
					if(consumed!=null)
						return consumed;	
				}
			}
		}
		return null;
    }

	@SuppressLint("RestrictedApi")
	@Override
	public boolean dispatchKeyEvent(KeyEvent event)
	{	
	
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).dispatchKeyEvent(event);
					if(consumed)
						return consumed;	
				}
			}
		}

		Gamepad.handleKeyEvent(event);
		//noinspection RestrictedApi		
		return super.dispatchKeyEvent(event);
	}

	@Override
	public boolean dispatchGenericMotionEvent(MotionEvent event)
	{
	
		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
			{
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase)
				{
					boolean consumed =((IExtensionBase)RunnerActivity.mExtension[i]).dispatchGenericMotionEvent(event);
					if(consumed)
						return consumed;	
				}
			}
		}
	
		//Log.i( "yoyo", "MotionEvent - " + event.toString() );
		if ((event.getSource() == InputDevice.SOURCE_JOYSTICK) || (event.getSource() == InputDevice.SOURCE_GAMEPAD)) 
		{
			Gamepad.handleMotionEvent(event);

			// BUGFIX: Prevent consuming gamepad events in order to support system virtual keyboard navigation
			if(m_keyboardController == null || m_keyboardController.VirtualKeyboardGetStatus() == false)
			{
				return true;
			}
		}

		return super.dispatchGenericMotionEvent(event);
	}
    
    /* Checks that this activity really is the YoYo Runner */
    private boolean checkIsYoYoRunner() {
    
		

    	boolean yoyoRunner = false;
		try {
			InputStream is = getResources().getAssets().open( "game.droid" );
			if (is != null) {
				yoyoRunner = false;
				Log.i( "yoyo", "#######!!!!!!! Checking for runner - found assets " );
				is.close();
			} // end if
			else {
				yoyoRunner = true;
				Log.i( "yoyo", "#######!!!!!!! Checking for runner - not found assets" );
			} // end else
			
		} 
		catch( Exception e ) {
			yoyoRunner = true;
			Log.i( "yoyo", "#######!!!!!!! Checking for runner! failed");
		} // end catch
		
		//Log.i("yoyo", "File Path for INI:: " + _apkFilename );

		
		

		
		
		//for APK expansion - no game.droid in assets - in downloaded .obb
		if( yoyoRunner ) //Disabling for the moment as testing runner with proper package name
		{
			//String packageName = this.getComponentName().getPackageName();
			//Log.i( "yoyo", "#####!!!! package name is " + packageName );
		//	boolean bTestRunnerAPK = true;	//TESTING, obviously - so we can check APK expansion basics in runner
			//if( (!packageName.equals( "com.yoyogames.runner")))  //|| bTestRunnerAPK )
			
			
			Bundle bundle = null;
		try {
			ApplicationInfo ai = getPackageManager().getApplicationInfo(this.getComponentName().getPackageName(), PackageManager.GET_META_DATA);
			bundle = ai.metaData;
			String IsRunner = bundle.getString("IsBuiltAsYoYoRunner");
			String DynamicAssetDelivery = bundle.getString("YYDynamicAssetDelivery"); 

			if((DynamicAssetDelivery!=null) && (DynamicAssetDelivery.equals("Yes")))
			{
				Log.i("yoyo","Found DynamicAssetDelivery flag in manifest");
				this.UseDynamicAssetDelivery = true;
				yoyoRunner = false;	
			}
			else if(IsRunner!=null && IsRunner.equals("Yes"))
			{
				//We are a runner build, carry on
				Log.i("yoyo","Found Runner flag in manifest, not using APK expansion");
			}
			else
			{
				//no droid file, no runner manifest entry & final package - need to download assets
				Log.i( "yoyo", "#######!!!!!!! using APK Expansion file" );
				yoyoRunner = false;
				this.UseAPKExpansionFile = true;
			}
		} 
		catch( Exception _e ) 
		{
			Log.d( "yoyo", "Exception while reading package meta data" +_e.toString() );
		} // end catch   	 
			
			
		}
		
		
		
		
		
		return yoyoRunner;
    }
    private void setupExtensions()
    {
    
		if(mExtension!=null)
		{
			return; //Already initialised...
		}
    
		if(mYYPrefs==null)
		{
			Log.i("yoyo","Unable to initialise extensions as preferences have not been loaded");
			return;
		}
    
    	int numexts = mYYPrefs.getInt("YYNumExtensionClasses");
        	
    	if(numexts>0)
    		mExtension = new Object[numexts];
    	
    	for(int i=0;i<numexts;i++)
    	{
    		String ExtClass = mYYPrefs.getString("YYExtensionClass"+i);
    		//String ExtInterface = mYYPrefs.getString("YYExtensionClassInterface"+i);
        	
    		if(ExtClass!=null && !ExtClass.isEmpty()) //May not have an android class
    		{
    			
				try{
					String FullClassName = "${YYAndroidPackageName}."+ExtClass;
					Log.i("yoyo","Attempting to initialise extension class " + FullClassName);
					mExtension[i] = (Object)(Class.forName(FullClassName).getConstructor().newInstance());
					
					
					
						try{
							Method method = mExtension[i].getClass().getMethod("Init");
							if(method != null)
							{
								Log.i("yoyo","Method found, attempting to invoke Init");
								method.invoke(mExtension[i]);
							}
						}
						catch(Exception e)
						{
							Log.i("yoyo", "No Init method found on extension class:"+ ExtClass + " returned " +e.getMessage());
							e.printStackTrace();
						}

					}
				catch(Exception e)
				{
					Log.i("yoyo","Exception thrown attempting to create extension class " + e.getMessage());
					e.printStackTrace();
				}
    			
    		}
    	}
        	
    }

    
    /* Checks to see if the current device is an XPeria play */
    private void checkXPeriaPlay() {
    
	    Log.i( "yoyo", "@@@@@@@ Build.Display = " + android.os.Build.DISPLAY + " BRAND=" + android.os.Build.BRAND + 
        						" DEVICE=" + android.os.Build.DEVICE + " MANUFACTURER=" + android.os.Build.MANUFACTURER+ 
        						" MODEL=" + android.os.Build.MODEL + " PRODUCT="  + android.os.Build.PRODUCT
        						);
        XPeriaPlay = (android.os.Build.MANUFACTURER.equals("Sony Ericsson")) && (android.os.Build.MODEL.startsWith("R800"));
        Log.i( "yoyo", "@@@@@@@ XPeriaPlay=" + XPeriaPlay + " manufacturer=" + android.os.Build.MANUFACTURER.equals("Sony Ericsson") + " model=" +  android.os.Build.MODEL.startsWith("R800"));
    }

	private Handler mRestoreImmersiveModeHandler = new Handler();

	private Runnable restoreImmersiveModeRunnable = new Runnable()
	{
		public void run() 
		{
			setupUiVisibility();      
		}
	};
	public void setupUiVisibilityDelayed()
	{
		// we restore it now and after 500 ms!
		mRestoreImmersiveModeHandler.postDelayed(restoreImmersiveModeRunnable, 500); 
	}
 
	public void   setupUiVisibility ()
	{
		if (mGLView != null)
		{
			 try {
        
        	Class parTypes[] = new Class[1];
        	parTypes[0] = Integer.TYPE;
	        mSetSystemUiVisibility = android.view.View.class.getMethod("setSystemUiVisibility", parTypes );
	        
			// if we are on 4.x (ice cream sandwich) or above (i.e. SystemUiVisibility is available then at least go into low profile)
			// if 4.4 (kitkat) or above then go into immersive mode
			int vis = 0x1;
			
			//Trying suggested fix of setting to off then on...
			
			
			//Log.i("yoyo", "OS VERSION SDK_INT = " + android.os.Build.VERSION.SDK_INT);
			if (android.os.Build.VERSION.SDK_INT >= 19 /*android.os.Build.VERSION_CODES.KITKAT*/) {
			
				if((RunnerActivity.UIVisibilityFlags&0x100)!=0) /* SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN*/
				{
					vis = RunnerActivity.UIVisibilityFlags&~(0x100);//0x706;
					ourSetSystemUiVisibility( vis );
				
					//Fixes suggested by http://vitiy.info/small-guide-how-to-support-immersive-mode-under-android-4-4/
				}
			//	Log.i("yoyo","Setting vis flags to "+UIVisibilityFlags);
				vis = RunnerActivity.UIVisibilityFlags; //SYSTEM_UI_FLAG_IMMERSIVE_STICKY|SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|SYSTEM_UI_FLAG_LAYOUT_STABLE
								//SYSTEM_UI_FLAG_FULLSCREEN|SYSTEM_UI_FLAG_HIDE_NAVIGATION
			} // end if
	        ourSetSystemUiVisibility( vis );
	        
			} 
			catch( Exception e ) {
	    		Log.i( "yoyo", "Exception while getting setSystemUiVisibility :: " + e.toString() );
			}
		}
	
	}
	

    
    /* Sets up the GL view that's reponsible for rendering (and GM processing...) */
    public void setupView() {
    
		Log.i( "yoyo", " + + + + setupView + + + +");
	    setContentView( R.layout.main );
        mGLView = (DemoGLSurfaceView)findViewById(R.id.demogl);

		

		setupUiVisibility();
		setupUiVisibilityDelayed();

		// start the draw events
		if (vsyncHandler != null)
		{
			((RunnerVsyncHandler)vsyncHandler).PostFrameCallback();
		}
    }

	@Override
    public void surfaceCreated(SurfaceHolder holder) {

		
		if (mGLView != null)
		{
			mGLView.surfaceCreated(holder);

			if(RunnerJNILib.mGameSpeedControl!=0)
			{
				SetGLViewFrameRate(RunnerJNILib.mGameSpeedControl);
			}
		}

		if (vsyncHandler != null)
		{
			// start the draw events
			((RunnerVsyncHandler)vsyncHandler).PostFrameCallback();
		}
	}

	@Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

		if (mGLView != null)
		{
			mGLView.surfaceChanged(holder, format, width, height);
			if(RunnerJNILib.mGameSpeedControl!=0)
			{
				SetGLViewFrameRate(RunnerJNILib.mGameSpeedControl);
			}
		}
	}
	
	@Override
    public void surfaceDestroyed(SurfaceHolder holder) {

		if (mGLView != null)
		{
			mGLView.surfaceDestroyed(holder);
		}
        // We need to wait for the render thread to shut down before continuing because we
        // don't want the Surface to disappear out from under it mid-render.  The frame
        // notifications will have been stopped back in onPause(), but there might have
        // been one in progress.        
	}
	@TargetApi(android.os.Build.VERSION_CODES.R)
	public void SetGLViewFrameRate(float fps)
	{
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R)
		{
			Surface s = mGLView.getHolder().getSurface();
			s.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
		}
	}

    private void ourSetSystemUiVisibility( int _vis ) {
    	if (mSetSystemUiVisibility != null) {
    		try {
    			mSetSystemUiVisibility.invoke( mGLView, _vis );
	    //		Log.i( "yoyo", "mSetSystemUiVisibility(" + _vis + ")" );
    		} catch( Exception _e ) {
    			Log.i( "yoyo", "Exception while calling setSystemUiVisibility " + _e.toString() );
    		} // end catch
    	} // end if
    	else {
	    		Log.i( "yoyo", "!!!!Unable to do mSetSystemUiVisibility(" + _vis + ")" );
    	} // end else	
    }


/*    private Dialog createDialog(int titleId, int messageId) 
    {
        String helpUrl = replaceLanguageAndRegion(getString(R.string.help_url));
        Log.i("yoyo", helpUrl);

        final Uri helpUri = Uri.parse(helpUrl);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(titleId)
            .setIcon(android.R.drawable.stat_sys_warning)
            .setMessage(messageId)
            .setCancelable(false)
            .setPositiveButton(android.R.string.ok, null)
            .setNegativeButton(R.string.learn_more, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, helpUri);
                    startActivity(intent);
                }
            });
        return builder.create();
    }
   */
    /**
     * Replaces the language and/or country of the device into the given string.
     * The pattern "%lang%" will be replaced by the device's language code and
     * the pattern "%region%" will be replaced with the device's country code.
     *
     * @param str the string to replace the language/country within
     * @return a string containing the local language and region codes
     */
    private String replaceLanguageAndRegion(String str) {
        // Substitute language and or region if present in string
        if (str.contains("%lang%") || str.contains("%region%")) {
            Locale locale = Locale.getDefault();
            str = str.replace("%lang%", locale.getLanguage().toLowerCase(Locale.US));
            str = str.replace("%region%", locale.getCountry().toLowerCase(Locale.US));
        }
        return str;
    }
    
  
    public int GetOrientation()
    {
		int ret = 0;
    	int rotation = getWindowManager().getDefaultDisplay().getRotation();

		Configuration configuration = getResources().getConfiguration();   
    		
		if(configuration.orientation == Configuration.ORIENTATION_LANDSCAPE &&  
		   (rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) ||  
		   configuration.orientation == Configuration.ORIENTATION_PORTRAIT &&   
		   (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270))   
		{   
			ret = rotation;
		} // end if
		else {
			ret = (rotation + 1) & 0x3;
		} // end else
		
		Log.i("yoyo", "calculated orientation - " + ret + " from rotation " + rotation );
		return ret;
    } // end GetOrientation
    
    @Override
    public void onConfigurationChanged( Configuration newConfig ) {
		super.onConfigurationChanged(newConfig);

		Orientation = GetOrientation();
		
		// Update and report initial physical keyboard status
		RunnerKeyboardController keyboardController = GetKeyboardController();
		if(keyboardController != null)
		{
			boolean physicalKeyboardConnected = (getResources().getConfiguration().hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_NO ? true : false);
			keyboardController.SetPhysicalKeyboardConnected(physicalKeyboardConnected);
			//keyboardController.VirtualKeyboardReportStatus(false);
		}

		if(RunnerActivity.mExtension!=null)
		{
			for(int i=0;i<RunnerActivity.mExtension.length;i++)
  			{	 
				if(RunnerActivity.mExtension[i] instanceof IExtensionBase )
					((IExtensionBase)RunnerActivity.mExtension[i]).onConfigurationChanged(newConfig);
			}
		}
    } // end onConfigurationChanged     



	public float getRefreshRate()
	{
		float refresh = 60.0f;

		refresh = getWindowManager().getDefaultDisplay().getRefreshRate();

		if (refresh < 10.0f)		// errr - on my Xperia Play for example I got a value of 0.012, and I've read of other people getting numbers like 0.34 :/
		{
			refresh = 60.0f;
		}

		return refresh;
	}

	public RunnerKeyboardController GetKeyboardController()
	{
		if(m_keyboardController == null)
		{
			View activityView = getWindow().getDecorView();
			m_keyboardController = RunnerKeyboardController.Create(this, activityView, ViewHandler);
		}

		return m_keyboardController;
	}
}