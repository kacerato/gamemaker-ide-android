package ${YYAndroidPackageName};


import android.annotation.TargetApi;

import android.util.Log;
import android.view.Choreographer;



public class RunnerVsyncHandler implements Choreographer.FrameCallback
{
	public static final class Accessor { private Accessor() {} }
	private static final Accessor accessor = new Accessor();
	//private long lastFrameTime = 0;
	@Override
    public void doFrame(long frameTimeNanos) {
        // The events should not start until the RenderThread is created, and should stop
        // before it's nulled out.

		DemoGLSurfaceView mGLView = RunnerActivity.CurrentActivity.GetGLView(accessor);

		//long duration = frameTimeNanos - lastFrameTime;

		
		//lastFrameTime = frameTimeNanos;

		if ((mGLView != null) && (mGLView.mRenderer != null))
		{									
			DemoRenderer.elapsedVsyncs++;
		}

		//Log.i("yoyo", "doFrame: " + frameTimeNanos + " duration:" + duration);
		Choreographer.getInstance().postFrameCallback(this);
	}

	public void PostFrameCallback()
	{
		Choreographer.getInstance().postFrameCallback(this);
	}

	public void RemoveFrameCallback()
	{
		Choreographer.getInstance().removeFrameCallback(this);
	}
}