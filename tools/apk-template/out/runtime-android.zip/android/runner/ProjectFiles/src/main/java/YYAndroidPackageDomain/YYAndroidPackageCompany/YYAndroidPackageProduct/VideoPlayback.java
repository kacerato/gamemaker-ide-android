package ${YYAndroidPackageName};


import ${YYAndroidPackageName}.RunnerActivity;
import com.yoyogames.runner.RunnerJNILib;
import android.util.Log;
import java.nio.ByteBuffer;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.res.*;
import android.graphics.Point;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.*;

import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;

import android.graphics.SurfaceTexture;

import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;


import java.io.InputStream;
import java.io.IOException;
import java.io.FileDescriptor;


public class VideoPlayback  extends RunnerSocial implements	OnBufferingUpdateListener, 
															OnCompletionListener,
															OnErrorListener,
															OnInfoListener,
															OnPreparedListener,
															OnSeekCompleteListener,
															OnVideoSizeChangedListener,
															TextureView.SurfaceTextureListener
{
    private static MediaPlayer mMediaPlayer;
	private static Resources mResources;
	private static AssetManager mAssetManager;
	private static TextureView mTextureView;

	private static Context mContext = null;
	private static boolean mInitialised = false;
    private static final int EVENT_OTHER_SOCIAL = 70;
	
	private int video_format_rgba = 0;
	private int video_format_yuv = 1;

	private int video_status_closed = 0;
	private int video_status_preparing = 1;
	private int video_status_playing = 2;
	private int video_status_paused = 3;
	
	//https://help.yoyogames.com/hc/en-us/articles/360000594391-video-draw
	// 0: Everything is working as it should
	// -1: There has been an error of some kind
	// -2: The video playback has finished
	private int VideoPlayback_Status = -2;
	
    public double VideoPlayback_Status()
    {
		//https://help.yoyogames.com/hc/en-us/articles/360000594391-video-draw
		// 0: Everything is working as it should
		// -1: There has been an error of some kind
		// -2: The video playback has finished
		return (double) VideoPlayback_Status;
    }
    
    public void VideoPlayback_SetVolume(double val)
    {
		volume = val;
		
		if(!mInitialised)
			return;
		
        mMediaPlayer.setVolume((float)volume,(float)volume);
    }

    public void VideoPlayback_Close()
    {
		if(!mInitialised)
			return;
		
		player_status = video_status_closed;// "Closed";
		
		VideoPlayback_Status = -2;
		mContext = null;
		mInitialised = false;
		mMediaPlayer.stop();
        mMediaPlayer.release();

		mTextureView=null;

		//MediaPlayer doesn't give onCompleted when stopping so we'll fire the video_end here as well
		int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
		RunnerJNILib.DsMapAddString(dsMapIndex,"type","video_end");
		RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex,EVENT_OTHER_SOCIAL);
    }
    
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) 
    {
        //Log.i("yoyo","VideoPlayback SurfaceTextureAvailable with width " + width + " height " + height);
        Surface s = new Surface(surface);
        mMediaPlayer.setSurface(s);
        //mTextureView.setVisibility(View.INVISIBLE); //try it here
    }
	
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) 
    {
        Log.i("yoyo","VideoPlayback onSurfaceTextureSizeChanged with width " + width + " height " + height);    
    }

    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) 
    {
		//VideoPlayback_Close()
        return true;
    }

    public void onSurfaceTextureUpdated(SurfaceTexture surface) 
    {
        // Invoked every time there's a new Camera preview frame
    }
	
    public void VideoPlayback_PlayVideo(String videoName)
    {
        final VideoPlayback vidplayer = this;
        RunnerActivity.CurrentActivity.runOnUiThread(new Runnable() 
		{
	        @Override
	        public void run() 
			{
				try
				{
					if(mInitialised)
					{
						Log.i("yoyo","Please close video player before attempting to play a new one");
						return;
					}

					//if(!mInitialised)//Not the best idea... at start a new video a frame appear from the last finished video
					{
						vidplayer.mContext = RunnerJNILib.ms_context;
						vidplayer.mResources = vidplayer.mContext.getResources();
						vidplayer.mAssetManager = vidplayer.mResources.getAssets();
						vidplayer.mMediaPlayer = new MediaPlayer();
						vidplayer.mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
						vidplayer.mMediaPlayer.setOnCompletionListener(vidplayer);
						vidplayer.mMediaPlayer.setOnInfoListener(vidplayer);
						vidplayer.mMediaPlayer.setOnErrorListener(vidplayer);
						vidplayer.mMediaPlayer.setOnPreparedListener(vidplayer);
						vidplayer.mMediaPlayer.setOnBufferingUpdateListener(vidplayer);
						vidplayer.mMediaPlayer.setOnSeekCompleteListener(vidplayer);
						//mMediaPlayer.setOnTimedTextListener(vidplayer);
						vidplayer.mMediaPlayer.setOnVideoSizeChangedListener(vidplayer);	
						
						vidplayer.mTextureView = new TextureView(vidplayer.mContext);
						vidplayer.mTextureView.setSurfaceTextureListener(vidplayer);
						ViewGroup viewGroup = (ViewGroup)(((Activity)vidplayer.mContext).findViewById(R.id.demogl).getParent());
					//	RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(1,1);
					
						FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(1, 1); //doesn't seem to affect the res it's rendered at
						viewGroup.addView(vidplayer.mTextureView,0,flp); //This hides it behind the main opengl view
					
						if( vidplayer.mTextureView == null)
						{
							Log.i("yoyo","VideoPlayback, failed to create textureview");
							return;
						}
					}
					
					mMediaPlayer.reset();
					
					//mMediaPlayer.setVolume((float)leftVolume,(float)rightVolume);
					//mMediaPlayer.setLooping(looping >= 0);
					
					AssetFileDescriptor assetDescriptor = mAssetManager.openFd(videoName);
					mMediaPlayer.setDataSource(assetDescriptor.getFileDescriptor(), assetDescriptor.getStartOffset(), assetDescriptor.getLength());
					assetDescriptor.close();
					mMediaPlayer.prepareAsync();

					VideoPlayback_Status = 0;
					player_status = video_status_preparing;// "Preparing";
                }
                catch (Exception e)
                {
					try
					{
						Log.i("yoyo","Unable to find media:" + videoName + " in bundle, trying to play from URL");
						mMediaPlayer.setDataSource(videoName);
						mMediaPlayer.prepareAsync();
						VideoPlayback_Status = 0;
						player_status = video_status_preparing;// "Preparing";
					}
					catch(IOException ex)
					{
						VideoPlayback_Status = -1;
						Log.i("yoyo","Exception thrown initing video player:" + ex);
					}
                }
            };
        });
	}
    
    public double VideoPlayback_VideoWidth()
    {
		if(!mInitialised)
			return 0;
		
        try
		{
			return (int)mMediaPlayer.getVideoWidth();
			//Bitmap bmp = mTextureView.getBitmap((int)VideoPlayback_VideoWidth(),(int)VideoPlayback_VideoHeight());
			//return (double)bmp.getWidth();
        }
        catch(Exception e)
        {
           Log.i("yoyo","Exception thrown attempting to get video width:" + e);
        }
		
        return 0;
    }
     
    public double VideoPlayback_VideoHeight()
    {
		if(!mInitialised)
			return 0;
		
        try
		{
			return (int)mMediaPlayer.getVideoHeight();
			//Bitmap bmp = mTextureView.getBitmap((int)VideoPlayback_VideoWidth(),(int)VideoPlayback_VideoHeight());
			//return (double)bmp.getHeight();
        }
        catch(Exception e)
        {
            Log.i("yoyo","Exception thrown attempting to get video height:" + e);
        }
		
        return 0;
    }
	
	public double VideoPlayback_WriteToBuffer(ByteBuffer bytes)
	{
		//Log.i("yoyo","bytes.position(): "+(int)bytes.position() + " remaining():"+ (int)bytes.remaining());

		try
		{
            if(mTextureView != null)
            {
                Bitmap bmp = mTextureView.getBitmap(mMediaPlayer.getVideoWidth(),mMediaPlayer.getVideoHeight());
				//Log.i("yoyo","video width "+(int)mMediaPlayer.getVideoWidth() + " ht:"+ (int)mMediaPlayer.getVideoHeight());

                if(bmp != null)
                {
					//Log.i("yoyo", "Bitmap size = " +bmp.getByteCount() + "width = "+bmp.getWidth() + " height="+bmp.getHeight());
                    bmp.copyPixelsToBuffer(bytes);
                    return 1;
                }
                else
                    Log.i("yoyo","Null bitmap generated");
            }
            else
                Log.i("yoyo","Surface View null when attempting to draw");
                     
        }
        catch(Exception e)
		{
			Log.i("yoyo","Exception thrown trying to write to surface:"+e);
        }
       
        return 0;
    }
	
	@Override 
	public void onCompletion(MediaPlayer mp) 
	{
		VideoPlayback_Close();
			
		//End
		int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
		RunnerJNILib.DsMapAddString(dsMapIndex,"type","video_end");
		RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex,EVENT_OTHER_SOCIAL);
		
		VideoPlayback_Status = -2;
	}

	@Override
	public boolean onInfo(MediaPlayer mp, int what, int extra) 
	{
		Log.i("yoyo","VideoPlayback: onInfo: " + getInfo(what) + " Extra: " + extra);
		return false; 
	}

	@Override 
	public boolean onError(MediaPlayer mp, int what, int extra) 
	{
		VideoPlayback_Status = -1;
		
		//VideoPlayback_Close();
		
		Log.i("yoyo","VideoPlayback onError: " + getInfo(what) + " Extra: " + extra);
		return false; 
	}

	@Override 
	public void onPrepared(MediaPlayer mp) 
	{
		mMediaPlayer.start();
		VideoPlayback_Status = 0;
		
		player_status = video_status_playing;// "Playing";
		
		mInitialised = true;
		
		if(Looping)
				VideoPlayback_EnableLoop(1.0);

		VideoPlayback_SetVolume(volume);
		
		//Start
		int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
		RunnerJNILib.DsMapAddString(dsMapIndex,"type","video_start");
		RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex,EVENT_OTHER_SOCIAL);
	}

	@Override 
	public void onBufferingUpdate(MediaPlayer mp, int percent) 
	{
		//Log.d("yoyo","VideoPlayback: onBufferingUpdate: "+percent+"%"); //gets a bit noisy
	}

	@Override 
	public void onSeekComplete(MediaPlayer mp) 
	{
		// int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
		// RunnerJNILib.DsMapAddString(dsMapIndex,"type","onSeekComplete");
		// RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex,EVENT_OTHER_SOCIAL);
	}

	//@Override 
	//public void onTimedText(MediaPlayer mp, TimedText text) {
		//Log.i("yoyo","VideoPlayback: onTimedText: "+text.getText());

		//int dsMapIndex = RunnerJNILib.jCreateDsMap(null, null, null);
		//RunnerJNILib.DsMapAddString( dsMapIndex, "type", "videoPlaybackTimedText" );
		//RunnerJNILib.DsMapAddString( dsMapIndex, "text", text.getText() );
		//RunnerJNILib.CreateAsynEventWithDSMap(dsMapIndex,EVENT_OTHER_SOCIAL);		
	//}

	@Override 
	public void onVideoSizeChanged(MediaPlayer mp, int width, int height) 
	{
		Log.d("yoyo","VideoPlayback: onVideoSizeChanged: " + width + "," + height);
	}
	
	private String getInfo(int val) 
	{
		switch (val) 
		{
			case MediaPlayer.MEDIA_INFO_UNKNOWN:
				return "MEDIA_INFO_UNKNOWN";
			case MediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING:
				return "MEDIA_INFO_VIDEO_TRACK_LAGGING";
			case MediaPlayer.MEDIA_INFO_BUFFERING_START:
				return "MEDIA_INFO_BUFFERING_START";
			case MediaPlayer.MEDIA_INFO_BUFFERING_END:
				return "MEDIA_INFO_BUFFERING_END";
			case MediaPlayer.MEDIA_INFO_BAD_INTERLEAVING:
				return "MEDIA_INFO_BAD_INTERLEAVING";
			case MediaPlayer.MEDIA_INFO_NOT_SEEKABLE:
				return "MEDIA_INFO_NOT_SEEKABLE";
			case MediaPlayer.MEDIA_INFO_METADATA_UPDATE:
				return "MEDIA_INFO_METADATA_UPDATE";
			case 3: //MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START:
				return "MEDIA_INFO_VIDEO_RENDERING_START";
			case 901: //MediaPlayer.MEDIA_INFO_UNSUPPORTED_SUBTITLE:
				return "MEDIA_INFO_UNSUPPORTED_SUBTITLE";
			case 902: //MediaPlayer.MEDIA_INFO_SUBTITLE_TIMED_OUT:
				return "MEDIA_INFO_SUBTITLE_TIMED_OUT";
			default:
				return "UNKNOWN: " + val;
		}
	}


	public void VideoPlayback_Pause()
	{
		if(!mInitialised)
			return;
		
		try
		{
			player_status = video_status_paused;// "Paused";
			mMediaPlayer.pause();
        }
        catch(Exception e)
        {
			
        }
	}

	public void VideoPlayback_Resume()
	{
		if(!mInitialised)
			return;
		
		try
		{
			mMediaPlayer.start();
			player_status = video_status_playing;// "Playing";
		}
        catch(Exception e)
        {
			
        }
	}
	
	boolean Looping = false;
	public void VideoPlayback_EnableLoop(double looping)
	{
		try
		{
			Looping = looping >= 0.5;
			mMediaPlayer.setLooping(Looping);
        }
        catch(Exception e)
        {
			
        }
	}
	
	public void VideoPlayback_SeekTo(double msec)
	{
		if(!mInitialised)
			return;
		
		try
		{
			mMediaPlayer.pause();
            mMediaPlayer.seekTo((int)msec);
			if(player_status == video_status_playing)//= "Playing")
				VideoPlayback_Resume();
        }
        catch(Exception e)
        {
        }
	}
	
	public double VideoPlayback_GetDuration()
	{
		if(!mInitialised)
			return 0;
		
		try
		{
            return mMediaPlayer.getDuration();
        }
        catch(Exception e)
        {
            return 0;
        }
	}
	
	public double VideoPlayback_GetPosition()
	{
		if(!mInitialised)
			return 0;
		
		try
		{
			return mMediaPlayer.getCurrentPosition();
        }
        catch(Exception e)
        {
            return 0;
        }
	}

	int player_status = video_status_closed;// "Closed";
	public double VideoPlayback_GetStatus()
	{
		return (double) player_status;
	}

	public double VideoPlayback_GetFormat()
	{
		return (double) video_format_rgba;
	}

	public double VideoPlayback_VideoIsLooping()
	{
		return Looping? 1.0:0.0;
	}
	
	double volume = 1;
	public double VideoPlayback_VideoGetVolume()
	{
		return volume;
	}

	public void onPause() 
	{
		if(!mInitialised)
			return;
		
		//VideoPlayback_Pause();
		//Paused, but not declared in status, maybe in onResume we need back to play
		try
		{
			mMediaPlayer.pause();
			//player_status = video_status_paused;// "Paused";
        }
        catch(Exception e)
        {
			
        }
	}
	
	public void onResume() 
	{
		if(!mInitialised)
			return;
		
		if(player_status == video_status_playing)//= "Playing")
			VideoPlayback_Resume();
	}
}

