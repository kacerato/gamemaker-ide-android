package com.yoyogames.runner;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.lang.Thread;
import java.lang.UnsatisfiedLinkError;
import java.net.URLConnection;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Class;
import java.util.Locale;
import java.nio.ByteBuffer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Debug;
import android.provider.Settings;
import android.provider.Settings.Secure;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.EditText;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.content.res.AssetManager;
import android.content.ClipboardManager;
import android.content.ClipData;

import android.annotation.SuppressLint;

//import com.openfeint.api.ui.Dashboard;
import ${YYAndroidPackageName}.RunnerActivity;

import ${YYAndroidPackageName}.RunnerKeyboardController;
import ${YYAndroidPackageName}.DemoGLSurfaceView;
import ${YYAndroidPackageName}.DemoRenderer;
import ${YYAndroidPackageName}.Gamepad;
import ${YYAndroidPackageName}.VideoPlayback;

import ${YYAndroidPackageName}.R;
import ${YYAndroidPackageName}.ISocial;

import android.os.Build;

import android.os.Environment;

import android.app.NotificationManager;

// Wrapper for native library
public class RunnerJNILib {

    public static Context ms_context;
    public static MediaPlayer ms_mp;
    public static boolean ms_exitcalled = false;	
	public static String ms_versionName;
	public static boolean ms_loadLibraryFailed = false;
	public static VideoPlayback mVideoPlayback;
	public static int mMaxRefreshRateSupported = 0;
	public static int mGameSpeedControl = 0;
	public static int mCurrentRefreshRate = 0;
	public static ClipboardManager mClipboard; 
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
   public static void Init() {
		try {
			//System.loadLibrary("c++_shared");
			System.loadLibrary("yoyo");
		} 
		catch( UnsatisfiedLinkError e) {
			Log.i( "yoyo", "Unsatisfied link error - " + e );
			ms_loadLibraryFailed = true;
			ms_exitcalled = true;
			/*
			*/
		} // end catch
        ms_mp = null;
    } // end Init
     
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    public static void Init(Context _context) {
    	ms_context = _context;
		mVideoPlayback = new VideoPlayback();
		mClipboard = (ClipboardManager) ms_context.getSystemService(Context.CLIPBOARD_SERVICE);
    }
    
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    // Exit the application in a thread safe way
    public static void ExitApplication() {
		if(!ms_exitcalled)
		{
		Log.i("yoyo", "First exit application called");
			ms_exitcalled = true;
    		RunnerActivity.ViewHandler.post( new Runnable() {
    			public void run() {
    				RunnerActivity.CurrentActivity.finish();
    			}
    		});
    	}
    }

	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    public static native void Startup(String _apkPath, String _saveFilesDir, String _packageName, int _sleepMargin,boolean dynamicassetdelivery);
    public static native boolean UpdateGameSpeed();
	public static native boolean ChangeInitialScreenFrequency();
	
    public static native void OnDisplayFrequencyChanged();
    public static native int Process(int _width, int _height, float _accelX, float _accelY, float _accelZ, int _keypadStatus, int _orientation, float _refreshrate );
    public static native void MouseMoveEvent( float _x, float _y );
    public static native void MouseButtonEvent( int _button, boolean _down );
    public static native void MouseWheelEvent( float _delta );
    public static native void TouchEvent( int _type, int _index, float _x, float _y, int _numTouchesInEvent);
    public static native void RenderSplash(   int  _screenWidth, int _screenHeight, int _texWidth, int _texHeight, int _pngWidth, int _pngHeight, int fillmode, int colour );
    public static native void Resume( int _param );
    public static native void Pause( int _param );
 //   public static native void AddString( String _string );

    public static native void BackKeyLongPressEvent( );
    public static native void KeyEvent( int _type, int _keycode, int _keychar, int _eventSource, int _repeatCount );
    public static native void SetKeyValue( int _type, int _val, String _valString );
	
    public static native String GetSaveFileName( String _fileName );
    public static native String[] ExpandCompressedFile( String _destLocalPath, String _compressedFileName );
    public static native void HttpResult( byte[] _resultString, int _httpStatus, int _id,String _finalURL, String _responseHeaders);
    public static native void HttpProgress( byte[] _resultString, int _httpStatus, int _id,String _finalURL, String _responseHeaders,int _contentLength);
    public static native void HttpResultString( String _resultString, int _httpStatus, int _id);
    public static native void InputResult( String _resultString, int _httpStatus, int _id);
    public static native void LoginResult( String _userName, String _password, int _id);
    public static native void CloudResultData( byte[] _resultString, byte[] _resultDesc, int _status, int _id);

    public static native void CloudResultString( String _resultString, int _status, int _id);
    
    
    public static native int  jCreateDsMap(String[] keys,String[] svals,double[] sdoublevals);
	public static native void DsMapAddDouble(int mapindex, String key, double val);
	public static native void DsMapAddString(int mapindex, String key, String val);
	public static native void CreateAsynEventWithDSMap(int mapindex, int eventindex);
	
	public static native void OnVirtualKeyboardStatus(String status, int height);
	public static native void OnVirtualKeyboardTextInserted(int[] text, int textOffset);


	// RK :: new Gamepad functions
	public static native void onGPDeviceAdded( int _deviceId, String _name, String _desc, int _productId, int _vendorId, int _numAxes, int _numHats, int _buttonMask );
	public static native void onGPDeviceRemoved( int _deviceId );
	public static native void onGPNativeAxis( int _deviceId, int _axis, float _value );
	public static native void onGPNativeHat( int _deviceId, int _hat, float _valueX, float _valueY );
	public static native void onGPKeyUp( int _deviceId, int _keyCode );
	public static native void onGPKeyDown( int _deviceId, int _keyCode );
	public static native void onGamepadChange();
    
    public static native void OnMicPermReqResult(boolean granted, long callback, long arg);
     
    public static native int CreateVersionDSMap(int sdkint,
			String RELEASE,
			String MODEL,
			String DEVICE,
			String MANUFACTURER,
			String CPU_ABI,
			String CPU_ABI2,
			String BOOTLOADER,
			String BOARD,
			String version,
			String region,
			String versionName,
			boolean physicalKeyboardAvailable);
    
    
    
    
    public static native int getGuiHeight();
    public static native int getGuiWidth();
    public static native int dsMapCreate();
    public static native int dsListCreate();
	public static native void dsMapAddString(int _dsMap, String _key, String _value);
	public static native void dsMapAddInt(int _dsMap, String _key, int _value);
	public static native void dsListAddString(int _dsList, String _value);
	public static native void dsListAddInt(int _dsMap, int _value);


	public static native int	dsListGetSize(int _dsList);
	public static native String dsListGetValueString(int _dsList, int _idx);
	public static native int	dsListGetValueInt(int _dsList, int _idx);
	public static native double dsListGetValueDouble(int _dsList, int _idx);

	public static native String extOptGetString(String _ext, String _opt);
	public static native double extOptGetReal(String _ext, String _opt);
	public static native String extGetVersion(String _ext);

	public static native ByteBuffer bufferGetByteBuffer(int _buffer);
	public static native ByteBuffer bufferResize(int _buffer, int _newSize);


	// Bluetooth controller feedback
	public static native void iCadeEventDispatch(int _button, boolean _down);
	public static native void registerGamepadConnected(int _deviceIndex, int _buttonCount, int _axisCount);

	public static native int initGLFuncs(int _usingGL2);
	public static native boolean canFlip(); 
    
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static int GetDefaultFrameBuffer() {
		return DemoRenderer.m_defaultFrameBuffer;
	}

	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static int UsingGL2() {
		return DemoGLSurfaceView.m_usingGL2;
	}
	
	public static int GLSupportsASTC() {
		return DemoGLSurfaceView.m_astcSupported;
	}

	public static void WaitForVsync() {
		DemoRenderer.WaitForVsync();
	}

	public static int HasVsyncHandler() {
		return RunnerActivity.CurrentActivity.vsyncHandler != null ? 1 : 0;
	}

	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    public static void OpenURL( String _url ) {
    	try {
    		Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(_url));
    		ms_context.startActivity(myIntent);
    	} catch (Exception e) {
    		Log.i("yoyo", "OpenURL failed: " + e);
    	}
    } // end OpenURL
    
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    public static void SetThreadPriority( int _priority ) {
    	Log.i("yoyo", "SetThreadPriority("+_priority);
 		Thread th = Thread.currentThread();
 		th.setPriority(_priority);
    }
     
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    public static void LeaveRating( String _text, String _yes, String _no, String _url )
    {
    	Log.i( "yoyo", "LeaveRating("+_text+", "+_yes+", "+_no+", "+_url+")");
    	final String sText = _text;
    	final String sYes = _yes;
    	final String sNo = _no;
    	final String sUrl = _url;
    	RunnerActivity.ViewHandler.post( new Runnable() {
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		builder.setMessage( sText)
    	    			.setCancelable(false)
    	    			.setPositiveButton( sYes, new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					// goto URL
    	    					OpenURL( sUrl );
    	    				}
    	     			})
    	    			.setNegativeButton( sNo, new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					dialog.cancel();
    	    				}
    	    			});
    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});
    } // end LeaveRating
     

    


    


    

    
    
    public static int OsGetInfo()
    {
		//get info & ping back to create the ds map, then return the index of that map...
		
		String version = System.getProperty("os.version",""); //Returns empty string if not found
		String region = System.getProperty("user.region","");
		
		boolean physicalKeyboardAvailable = false;		
		RunnerKeyboardController keyboardController = RunnerActivity.CurrentActivity.GetKeyboardController();
		if(keyboardController != null)
		{
			physicalKeyboardAvailable = keyboardController.GetPhysicalKeyboardConnected();
		}
		
	/*	java.util.Properties props = System.getProperties();
		java.util.Enumeration e = props.propertyNames();
		while (e.hasMoreElements()) {
			String k = (String) e.nextElement();
			String v = props.getProperty(k);
			Log.i("yoyo","Sys prop:" + k + " val:" +v);
		}
		
		Log.i("yoyo","os.BOARD:"+android.os.Build.BOARD);
		Log.i("yoyo","os.BOOTLOADER:"+android.os.Build.BOOTLOADER);
		Log.i("yoyo","os.BRAND:"+android.os.Build.BRAND);
		Log.i("yoyo","os.CPU_ABI:"+android.os.Build.CPU_ABI);
		Log.i("yoyo","os.CPU_ABI2:"+android.os.Build.CPU_ABI2);
		Log.i("yoyo","os.DEVICE:"+android.os.Build.DEVICE);
		Log.i("yoyo","os.DISPLAY:"+android.os.Build.DISPLAY);
		Log.i("yoyo","os.FINGERPRINT:"+android.os.Build.FINGERPRINT);
		Log.i("yoyo","os.HARDWARE:"+android.os.Build.HARDWARE);
		Log.i("yoyo","os.HOST:"+android.os.Build.HOST);
		Log.i("yoyo","os.MANUFACTURER:"+android.os.Build.MANUFACTURER);
		Log.i("yoyo","os.MODEL:"+android.os.Build.MODEL);
		Log.i("yoyo","os.PRODUCT:"+android.os.Build.PRODUCT);
			Log.i("yoyo","os.TYPE:"+android.os.Build.TYPE);
			Log.i("yoyo","os.USER:"+android.os.Build.USER);
	
			Log.i("yoyo","os.TAGS:"+android.os.Build.TAGS);
	
	
		Log.i("yoyo","Build.version.sdk_int"+ android.os.Build.VERSION.SDK_INT);
		Log.i("yoyo","Build.release" + android.os.Build.VERSION.RELEASE);
		
	*/
	
		int dsmapid =RunnerJNILib.CreateVersionDSMap(
			android.os.Build.VERSION.SDK_INT,
			android.os.Build.VERSION.RELEASE,
			android.os.Build.MODEL,
			android.os.Build.DEVICE,
			android.os.Build.MANUFACTURER,
			android.os.Build.CPU_ABI,
			android.os.Build.CPU_ABI2,
			android.os.Build.BOOTLOADER,
			android.os.Build.BOARD,
			version,
			region,
			ms_versionName,
			physicalKeyboardAvailable);
	
		return dsmapid;
    }
     
	
    
	public static Object CallExtensionFunction(String classname, String methodname, int argcount,Object [] args)
    {
		Object retObject = null;
		if(RunnerActivity.mExtension==null)
		{
			Log.i("yoyo","Attempting to call extension function with no extensions loaded " + methodname + " on class " + classname); 
			return retObject;
		}
		
		if(classname==null || methodname == null)
		{
			if(classname==null)
				Log.i("yoyo","Attempting to call extension function with null classname method:"+methodname);
			else if(methodname==null)
				Log.i("yoyo","Attempting to call extension function with null methodname on class:"+classname);
			
			
			return retObject;
		}
    
	//	Log.i("yoyo","Java side attempting to call extension function " + methodname + " on class " + classname); 
		try{
			Class<?> ReqClass = null;
		
			try{
				ReqClass = Class.forName("${YYAndroidPackageName}."+classname);
			}
			catch (ClassNotFoundException e)
			{
				Log.i("yoyo","Extension Class not found: " + "${YYAndroidPackageName}."+classname + " attempting to call " + methodname);
			}
		
			if(ReqClass !=null)
			{
	//		Log.i("yoyo","Found " + RunnerActivity.mExtension.length + " extensions");
			for( int j=0;j<RunnerActivity.mExtension.length;j++)
			{
					if(RunnerActivity.mExtension[j]!=null)
					{
				if(ReqClass.isInstance(RunnerActivity.mExtension[j]))
				{
					if(argcount >0)
					{
						Class [] cArg = new Class[argcount];
						
						for(int i=0;i<argcount;i++)
						{		
							cArg[i] = args[i].getClass();				
						}			
						
						try{
							Method method = RunnerActivity.mExtension[j].getClass().getMethod(methodname,cArg);
						
									Log.i("yoyo","Method found, attempting to invoke " + methodname);
							retObject = method.invoke(RunnerActivity.mExtension[j],args);
							break;
						}
						catch(Exception e)
						{
							Log.i("yoyo","Exception thrown calling method on extension class:"+e + " looking for " + methodname + " on " + classname + " " +e.getMessage());
							
							for(int ac=0;ac<argcount;ac++)
							{
								Log.i("yoyo","Argument " + ac+ " of type " + cArg[ac].toString());
							}
							e.printStackTrace();
							
							Method [] classMethods = RunnerActivity.mExtension[j].getClass().getMethods();
							
							for(int xx = 0;xx<classMethods.length;xx++)
							{
								Log.i("yoyo","Found method " + classMethods[xx].toString());
							}
							
							
						}
						
					}
					else
					{
						try{
							Method method = RunnerActivity.mExtension[j].getClass().getMethod(methodname);
						
					//		Log.i("yoyo","Method found, attempting to invoke "+methodname);
							retObject = method.invoke(RunnerActivity.mExtension[j]);
							break;
						}
						catch(Exception e)
						{
						//	Log.i("yoyo","Can't find argfree method on extension class:"+e.getMessage());
									Log.i("yoyo","Exception thrown calling argfree method on extension class:"+e + " looking for " + methodname + " on " + classname + " " +e.getMessage());
						
							e.printStackTrace();
						}
						
					}
						}
					
				}
				}
		
			}
		
		}
		catch(Exception e)
		{
			
			Log.i("yoyo","Exception thrown trying to call method "+ methodname + " on " + classname + " " +e.getMessage());
			e.printStackTrace();
		}	
		return retObject;
			
    }
    
    
    public static Object CallExtensionFunction(String classname, String methodname, int argcount,  double [] dblargs,Object []objargs)
    {
		Object retObject = null;
		if(RunnerActivity.mExtension==null)
		{
			Log.i("yoyo","Attempting to call extension function with no extensions loaded " + methodname + " on class " + classname); 
			return retObject;
		}
		
		if(classname==null || methodname == null)
		{
			if(classname==null)
				Log.i("yoyo","Attempting to call extension function with null classname method:"+methodname);
			else if(methodname==null)
				Log.i("yoyo","Attempting to call extension function with null methodname on class:"+classname);
			
			
			return retObject;
		}
    
		//Log.i("yoyo","Java side attempting to call extension function " + methodname + " on class " + classname); 
		try{
		
		Class<?> ReqClass = null;

			try{
				ReqClass = Class.forName("${YYAndroidPackageName}."+classname);
			}
			catch (ClassNotFoundException e)
			{
				Log.i("yoyo","Extension Class not found: " + "${YYAndroidPackageName}."+classname + " attempting to call " + methodname);
			}
		
			if(ReqClass !=null)
			{
				int i;
			//Log.i("yoyo","Found " + RunnerActivity.mExtension.length + " extensions");
			for( int j=0;j<RunnerActivity.mExtension.length;j++)
			{
				if(ReqClass.isInstance(RunnerActivity.mExtension[j]))
				{
					if(argcount >0)
					{
						Class [] cArg = new Class[argcount];
						Object []Args = new Object[argcount];
						

							for(i=0;i<argcount;i++)
						{
								if(objargs[i]!=null)//argtypes[i]==3)
							{
									cArg[i] = objargs[i].getClass();
									Args[i] = objargs[i];
							}
							else 
							{
								cArg[i] = double.class;
								Args[i] = dblargs[i];
							}
						}
						
						
							Method[] methods = ReqClass.getMethods();
							Method toInvoke = null;
							for(Method method :methods)
							{
								if(!methodname.equals(method.getName()))
									continue;

								Class<?>[] paramTypes = method.getParameterTypes();
								if(paramTypes==null || paramTypes.length!=argcount)
									continue;

								for(i=0;i<cArg.length;i++)
								{
									if (!paramTypes[i].isAssignableFrom(cArg[i]))
										break;
								}
								if(i!=cArg.length)
									continue;

								toInvoke = method;
								break;
							}

							if(toInvoke!=null)
							{
								try
								{
									retObject = toInvoke.invoke(RunnerActivity.mExtension[j],Args);
								}
								catch(InvocationTargetException e)
								{
									Throwable targetEx = e.getTargetException();
				
									Log.i("yoyo", "InvocationTargetException thrown trying to call method "+ methodname + " on " + classname);
									Log.i("yoyo", "Target exception: " + targetEx.getMessage() + ". Cause: " + targetEx.getCause() + ". Stack trace: \n" + Log.getStackTraceString(targetEx));

									Method [] classMethods = RunnerActivity.mExtension[j].getClass().getMethods();
									for(int xx = 0;xx<classMethods.length;xx++)
									{
										Log.i("yoyo","Found method " + classMethods[xx].toString());
									}
								}
								catch(Exception e)
								{
									Log.i("yoyo", "Exception3 thrown trying to call method "+ methodname + " on " + classname);
									Log.i("yoyo", "Exception:" + e.getMessage() + ". Details: " + e.toString() + ". Stack trace:\n"+Log.getStackTraceString(e));

									Method [] classMethods = RunnerActivity.mExtension[j].getClass().getMethods();
									for(int xx = 0;xx<classMethods.length;xx++)
									{
										Log.i("yoyo","Found method " + classMethods[xx].toString());
									}
								}
							}
							else
							{
								Log.i("yoyo","Unable to find method to invoke matching methodname:" + methodname +" on class:"+classname+ " with params:" );
								for(int p=0;p<cArg.length;p++)
								{
									Log.i("yoyo","param:"+p+":" + cArg[p]);
								}
							}
						}
						else
						{
							try
							{
								Method method = RunnerActivity.mExtension[j].getClass().getMethod(methodname);
								if(method == null)
								{
									Log.i("yoyo","Can't find argfree method on extension class:");
								}
								else
								{
									retObject = method.invoke(RunnerActivity.mExtension[j]);
								}
							}
							catch(Exception e)
							{
									Log.i("yoyo","Exception thrown trying to call " + methodname+ " on class " + classname+ " with no arguments:"+e.getMessage());
								e.printStackTrace();
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			Log.i("yoyo","Exception thrown trying to call method "+ methodname + " on " + classname);
			Log.i("yoyo",e.getMessage());

			e.printStackTrace();
		}	

		return retObject;
    }

 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static void ShowMessage(String _message ) {
    	Log.i( "yoyo", "ShowMessage(\""+_message+"\")");
    	
    	final String sMessage = _message;
    	final CountDownLatch latch = new CountDownLatch(1);
    	RunnerActivity.ViewHandler.post( new Runnable() {
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		builder.setMessage( sMessage)
    	    			.setCancelable(false)
    	    			.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					latch.countDown();
    	    				}
    	     			});
    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});
    	
    	try {
    		latch.await();
    	} catch( InterruptedException e ) {
    		Thread.currentThread().interrupt();
    	} // end catch
	} // end ShowMessage
	
 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static void ShowMessageAsync(String _message, int _id ) {
    	Log.i( "yoyo", "ShowMessageAsync(\""+_message+"\","+_id+")");
    	
    	final String sMessage = _message;
    	final int idDialog = _id;
    	RunnerActivity.FocusOverride = true;
    	RunnerActivity.ViewHandler.post( new Runnable() {
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		builder.setMessage( sMessage)
    	    			.setCancelable(false)
    	    			.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					RunnerJNILib.InputResult( "OK", 1,  idDialog);	
    	    				}
    	     			});
    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});
    	
	} // end ShowMessage
	
	
 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static String InputString( String _message, String _default ) {
    	Log.i( "yoyo", "InputString(\"" +_message+ "\", \""+_default+"\")");
    	
    	final String sMessage = _message;
    	final String sDefault = _default;
    	final CountDownLatch latch = new CountDownLatch(1);
    	RunnerActivity.ViewHandler.post( new Runnable() 
    	{
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		final EditText input = new EditText(ms_context);
    	    		input.setText(sDefault);
					builder.setView(input);
    	    		builder.setMessage(sMessage)
    	    			.setCancelable(false)
    	    			.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					RunnerActivity.InputStringResult = input.getText().toString();
    	    					latch.countDown();
    	    				}
    	     			});
					builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							RunnerActivity.InputStringResult = sDefault;
    	    				latch.countDown(); 
						}
					});

    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});
    	
    	try {
    		latch.await();
    	} catch( InterruptedException e ) {
    		Thread.currentThread().interrupt();
    	} // end catch
    	return RunnerActivity.InputStringResult;
	} // end ShowMessage	
	

	public static int DynamicAssetExists(String filename)
	{
		
		try{

		AssetManager assetManager = ms_context.getAssets();
		InputStream is = assetManager.open(filename.toLowerCase(Locale.ROOT));

		if(is!=null)
		{
		//	Log.i("yoyo","Found dynamic asset:"+filename);
			is.close();
			return 1;
		}
		}
		catch( IOException e) {

		}
		Log.i("yoyo","Failed to find asset:"+filename);
		return 0;

	}

	public static Object GetAssetManager()
	{
		//Log.i("yoyo","attempting to return GetAssetManager()");

		try{

			AssetManager assetManager = ms_context.getAssets();
			return assetManager;
			}
		catch( Exception _ioe) {
					Log.i("yoyo","Exception:"+_ioe.toString());
				} 

		return null;

	}



 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static void InputStringAsync( String _message, String _default, int _id ) {
    	Log.i( "yoyo", "InputStringAsync(\"" +_message+ "\", \""+_default+"\","+_id+")");
    	
    	final String sMessage = _message;
    	final String sDefault = _default;
    	final int idDialog = _id;
    	RunnerActivity.FocusOverride = true;
    	RunnerActivity.ViewHandler.post( new Runnable() 
    	{
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		final EditText input = new EditText(ms_context);
    	    		input.setText(sDefault);
					builder.setView(input);
    	    		builder.setMessage(sMessage)
    	    			.setCancelable(false)
    	    			.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					RunnerActivity.InputStringResult = input.getText().toString();
    	    					RunnerJNILib.InputResult( RunnerActivity.InputStringResult, 1,  idDialog);	
    	    				}
    	     			});
					builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							RunnerActivity.InputStringResult = sDefault;
   	    					RunnerJNILib.InputResult( RunnerActivity.InputStringResult, 0,  idDialog);	
						}
					});

    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});    	
	} // end InputStringAsync	
	
	
 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static int ShowQuestion(String _message ) {
    	Log.i( "yoyo", "ShowQuestion(\""+_message+"\")");
    	
    	final String sMessage = _message;
    	final CountDownLatch latch = new CountDownLatch(1);
		RunnerActivity.ShowQuestionYesNo = 0;
    	RunnerActivity.ViewHandler.post( new Runnable() {
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		builder.setMessage( sMessage)
    	    			.setCancelable(false)
    	    			.setPositiveButton( "Yes", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
								RunnerActivity.ShowQuestionYesNo = 1;
    	    					latch.countDown();
    	    				}
    	     			});
					builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							RunnerActivity.ShowQuestionYesNo = 0;
    	    				latch.countDown(); 
						}
					});
    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});
    	
    	try {
    		latch.await();
    	} catch( InterruptedException e ) {
    		Thread.currentThread().interrupt();
    	} // end catch
    	return RunnerActivity.ShowQuestionYesNo;
	} // end ShowMessage
	
 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static void ShowQuestionAsync(String _message, int _id ) {
    	Log.i( "yoyo", "ShowQuestionAsync(\""+_message+"\","+_id+")");
    	
    	
    	final String sMessage = _message;
    	final int idDialog = _id;
    	RunnerActivity.FocusOverride = true;
    	RunnerActivity.ViewHandler.post( new Runnable() {
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(ms_context);
    	    		builder.setMessage( sMessage)
    	    			.setCancelable(false)
    	    			.setPositiveButton( "Yes", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
	   	    					RunnerJNILib.InputResult( "1", 1,  idDialog);	
    	    				}
    	     			});
					builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
   	    					RunnerJNILib.InputResult( "0", 0,  idDialog);	
						}
					});
    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});    	
	} // end ShowQuestionAsync
	
	
	
 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	private static String HttpGetHeaders(HttpURLConnection _conn)
	{
		String headers = "";
		for (Map.Entry<String, List<String>> k : _conn.getHeaderFields().entrySet()) {
			for (String v : k.getValue()) {
				if(k.getKey()!=null)
					headers = headers + k.getKey() + ": " + v + "\r\n";				
				else
					headers = headers + "nokey" + ": " + v + "\r\n";	
			}
		}		
		return headers;
	}
	
	public static void HttpGet(String _url, int _id, int _timeout ) {
    	Log.i( "yoyo", "HttpGet(\""+_url+"\", "+_id+")");
		// lets run this on the main UI thread...
		final String url = _url;
		final int id = _id;
    	new Thread( new Runnable() {
    		 public void run() {
    		 
    			HttpURLConnection conn;
    			try 
    			{
    				URL connectURL = new URL(url);
    				conn = (HttpURLConnection)connectURL.openConnection();
    			}
    			catch( MalformedURLException _mue ) {
    				RunnerJNILib.HttpResultString( "MalformedURLException", 404,  id);	
    				conn = null;
    			}
				catch( IOException _ioe) {
					RunnerJNILib.HttpResultString( "IOException", 404,  id);	
    				conn = null;
				} 
    			if (conn != null) {
    				try
    				{   
    					conn.setRequestProperty("Accept-Encoding", "identity");
    					conn.setDoInput(true);
    					conn.setDoOutput(false); 					    					
    					conn.setUseCaches(false);//? why?
    					conn.setConnectTimeout(_timeout);
    					conn.connect();
						
	    				String finalurl = conn.getURL().toString();
    					int responseCode = conn.getResponseCode();
    					byte[] result = null;

						/* getInputStream() throws an IOException for some HTTP responses
						 * (such as a 404), in which case we need to use getErrorStream() to read
						 * the error response body.
						*/
						InputStream is;
						try {
							is = conn.getInputStream();
						}
						catch( IOException _ioe) {
							is = conn.getErrorStream();
						}

						byte[] buffer = new byte[ 4096 ];
						int n = -1;
						while( (n=is.read(buffer)) != -1 )
						{
							RunnerJNILib.HttpProgress( buffer, n, id, finalurl, "",conn.getContentLength());
						}
						is.close();

					   	Log.i( "yoyo", "http_get responseCode=" + responseCode + ", id=" + id+", finalurl="+finalurl+" headers=" +  HttpGetHeaders(conn));
    					RunnerJNILib.HttpResult( null, responseCode, id, finalurl, HttpGetHeaders(conn));	
    					
    					conn.disconnect();
    					conn = null;
    				}
    				catch( Exception _e) {
					   	Log.i( "yoyo", "Exception = " + _e.toString());
    					RunnerJNILib.HttpResultString( "IOException", 404,  id);	
    					conn = null;
    				}
    			} // end if    		 
    		 } // end run
    	}).start();
	} // end HttpGet
	
	public static void HttpPost(String _url, String _post, int _id, int _timeout ) {
    	Log.i( "yoyo", "HttpPost(\""+_url+"\", \""+_post+"\", "+_id+")");
		// lets run this on the main UI thread...
		final String url = _url;
		final String post = _post;
		final int id = _id;
    	new Thread( new Runnable() {
    		 public void run() {
    		 
    			HttpURLConnection conn;
    			try 
    			{
    				URL connectURL = new URL(url);
    				conn = (HttpURLConnection)connectURL.openConnection();
    			}
    			catch( MalformedURLException _mue ) {
    				RunnerJNILib.HttpResultString( "MalformedURLException", 404,  id);	
    				conn = null;
    			}
				catch( IOException _ioe) {
					RunnerJNILib.HttpResultString( "IOException", 404,  id);	
    				conn = null;
				} 
    			if (conn != null) {
    				try
    				{
    					conn.setDoInput(true);
    					conn.setDoOutput(true);
    					conn.setUseCaches(false);
    					conn.setRequestMethod("POST");
    					conn.setConnectTimeout(_timeout);
	    				
    					conn.connect();
	    				
    					byte[] postBytes = post.getBytes("UTF-8");
    					conn.getOutputStream().write(postBytes);
    					conn.getOutputStream().flush();
    					conn.getOutputStream().close();
    						    				
    					int responseCode = conn.getResponseCode();
    					Log.i("yoyo", "HttpPost: Got response code '" + responseCode + "'");
    					byte[] result = null;
    					String finalurl=null;
						try {    						
    						InputStream is = conn.getInputStream();    						
    						ByteArrayOutputStream out = new ByteArrayOutputStream();
    						byte[] buffer = new byte[ 4096 ];
    						int n = -1;    						
    						while ((n = is.read(buffer)) != -1) {    							
    							out.write(buffer, 0, n );
    						} // end while    						
    						result = out.toByteArray();
    						out.close();    						
							is.close();
    						finalurl = conn.getURL().toString();
    					}    					
    					catch (IOException _ioe) {
    						// e.g. a 405 response may have occurred, which is fine
    						Log.i("yoyo", "HttpPost: IO exception");
    					}

    					// Trick the runner into seeing this as a valid result whatever's happened by ensuring a true for (nDownloadOffset > 0)    					
    					if ((result == null) || (result.length == 0)) {    						
    						result = new byte[]{ '\0' };
    					}
	    					    				
    					RunnerJNILib.HttpResult( result, responseCode, id, finalurl, HttpGetHeaders(conn));	
    					
    					conn.disconnect();
    					conn = null;
    				}
    				catch( Exception _e) {
    					RunnerJNILib.HttpResultString( "IOException", 404,  id);	
    					conn = null;
    				}
    			} // end if    		 
    		 } // end run
    	}).start();
	} // end HttpPost
	
		
	public static void HttpRequest(String _url, String _method, String _headers, byte[] _post, int _id, int _timeout ) {
	
		Log.i( "yoyo", "HttpRequest(\""+_url+"\", \""+_method+"\", \""+_post+"\", "+_id+")");
		
		// lets run this on the main UI thread...
		final String url = _url;
		final String method = _method;
		final String headers = _headers;
		final byte[] post = _post;
		final int id = _id;		
		
    	new Thread( new Runnable() {
    		 public void run() {    		 
    			HttpURLConnection conn;
    			try 
    			{
    				URL connectURL = new URL(url);
    				conn = (HttpURLConnection)connectURL.openConnection();
    			}
    			catch( MalformedURLException _mue ) {
    				RunnerJNILib.HttpResultString("MalformedURLException", 404,  id);	
    				conn = null;
    			}
				catch( IOException _ioe) {
					RunnerJNILib.HttpResultString("IOException", 404,  id);	
    				conn = null;
				} 
    			if (conn != null) {
    				try
    				{
    					conn.setDoInput(true);
    					
    					if( (method.equals("GET")) || (method.equals("HEAD")) )
    					//if(post==null || post.isEmpty())
    					{
    						conn.setDoOutput(false);
    						Log.i( "yoyo", "Setting do output to false");
	
    					}
    					else 
    					{
    						Log.i( "yoyo", "Setting do output to true");
    						conn.setDoOutput(true); // theoretically only POST and PUT requests should have data but I'm not going to rely on it
    					}
    					conn.setUseCaches(false);
    					conn.setRequestMethod(method);
    					conn.setConnectTimeout(_timeout);
    					
						// Add set of custom headers now
						String[] kvps = headers.split("\r\n");
						for (String s : kvps) {
							String[] kvp = s.split(": ");
							if (kvp.length == 2) {
								Log.i("yoyo", "HttpRequest: Found header " + kvp[0] + ": " + kvp[1]);
								conn.setRequestProperty(kvp[0], kvp[1]);
							}
							else {
								Log.i("yoyo", "HttpRequest: Malformed header " + s);
							}
						}
												
						// Connect to the remote object				
    					conn.connect();
						
						// Add POST data if it's available once connection has been made
						if ((post != null) && (!method.equals("GET"))) 
						{
    						conn.getOutputStream().write(post);
    						conn.getOutputStream().flush();
    						conn.getOutputStream().close();
    					}    					
    					    					
    					
    					int responseCode = conn.getResponseCode();
    					Log.i("yoyo", "HttpRequest: Got response code '" + responseCode + "'");

						// Attempt to read response data
						byte[] result = null;
						InputStream is = null;
						try {    						
							is = conn.getInputStream();
						}catch(IOException _e) {;}
						
						try{
							//check error stream for response if no input stream
							if( is == null )
								is = conn.getErrorStream();
							if( is != null)
							{
    							ByteArrayOutputStream out = new ByteArrayOutputStream();
    							byte[] buffer = new byte[ 4096 ];
    							int n = -1;    						
    							while ((n = is.read(buffer)) != -1) {    							
    								out.write(buffer, 0, n );
    							} // end while    						
    							result = out.toByteArray();
    							out.close();    				
								is.close();
							}
    					}    					
    					catch (IOException _ioe) {
    						// e.g. a 405 response may have occurred, which is fine
    						Log.i("yoyo", "HttpRequest: IO exception:" + _ioe);
    					}
    					    					
    					// Trick the runner into seeing this as a valid result whatever's happened by ensuring a true for (nDownloadOffset > 0)    					
    					if ((result == null) || (result.length == 0)) {    						
    						result = new byte[]{ '\0' };
    					}
    					
						String finalurl = conn.getURL().toString();						
    					RunnerJNILib.HttpResult(result, responseCode, id, finalurl, HttpGetHeaders(conn));	
    					    					
    					conn.disconnect();
    					conn = null;    					
    				}
    				catch (SocketTimeoutException _se) {
   						Log.i("yoyo", "HttpRequest: request timed out");
    					RunnerJNILib.HttpResultString("HTTP request timed out", 404, id);
    					conn = null;
    				}
    				catch( Exception _e) {
   						Log.i("yoyo", "HttpRequest: exception:"+_e);
    					RunnerJNILib.HttpResultString("HTTP request exception", 404, id);
    					conn = null;
    				}
    			} // end if    		 
    		 } // end run
    	}).start();
		
	} // HttpRequest
	
	
	
 	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	@SuppressLint("InflateParams")
	public static void ShowLogin(String _defaultUsername, String _defaultPassword, int _id ) {
    	Log.i( "yoyo", "LoginDialog(\"" +_defaultUsername+ "\", \""+_defaultPassword+"\","+_id+")");
    	
    	final String sDefaultUserName = _defaultUsername;
    	final String sDefaultPassword = _defaultPassword;
    	final int idDialog = _id;
    	RunnerActivity.FocusOverride = true;
    	RunnerActivity.ViewHandler.post( new Runnable() 
    	{
    		 public void run() {
    	    		AlertDialog.Builder builder = new AlertDialog.Builder(RunnerActivity.CurrentActivity);
    	    		LayoutInflater factory = LayoutInflater.from(RunnerActivity.CurrentActivity);
    	  //  		final View textEntryView = factory.inflate( R.layout.userpasslayout, (ViewGroup)(RunnerActivity.CurrentActivity.findViewById(R.id.demogl).getParent()) );
    				final View textEntryView = factory.inflate( R.layout.userpasslayout, null );
					builder.setView(textEntryView);
					final EditText userNameEditText = (EditText)textEntryView.findViewById(R.id.username);
					final EditText passwordEditText = (EditText)textEntryView.findViewById(R.id.password);
					userNameEditText.setText( sDefaultUserName );
					passwordEditText.setText( sDefaultPassword );
    	    		builder.setCancelable(false)
    	    			.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
    	    				public void onClick( DialogInterface dialog, int id ) {
    	    					RunnerJNILib.LoginResult( userNameEditText.getText().toString() + '#' + passwordEditText.getText().toString(), userNameEditText.getText().toString(), idDialog ); 
    	    				}
    	     			});
					builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							RunnerJNILib.LoginResult( "", "", idDialog );
						}
					});

    	    		AlertDialog alert  = builder.create();
    	    		alert.show();    		 
    		 }
    	});
	} // end ShowLogin
	
	public static int CheckPermission(String _permission)
	{
		// Log.i("yoyo","Checking permission: " +_permission);
		
		boolean permission = false;
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && (_permission.equals("android.permission.WRITE_EXTERNAL_STORAGE") || _permission.equals("android.permission.READ_EXTERNAL_STORAGE")))
		{
			if(Environment.isExternalStorageManager())
				return 1;
			else
				return 0;
		}
		else
		if(Build.VERSION.SDK_INT >= 24 && _permission.equals("android.permission.POST_NOTIFICATIONS"))
		{
			NotificationManager notificationManager = (NotificationManager) RunnerActivity.CurrentActivity.getSystemService(RunnerActivity.CurrentActivity.NOTIFICATION_SERVICE);
			return notificationManager.areNotificationsEnabled()?1:0;
		}
		else
		{
			PackageManager packMgmr = ms_context.getPackageManager();
			
			int permissionCheck = ContextCompat.checkSelfPermission(RunnerActivity.CurrentActivity,_permission);
			if(permissionCheck==PackageManager.PERMISSION_GRANTED)
			{
				Log.i("yoyo","permission granted: " +_permission);
		
				return 1;
			}
			
			boolean sshow = ActivityCompat.shouldShowRequestPermissionRationale(RunnerActivity.CurrentActivity,_permission);	
				
			if(sshow)	
			{
				Log.i("yoyo","permission denied but not prevented from asking: " +_permission);
		
				return 0;
			}
		
			Log.i("yoyo","permission denied and shouldn't be requested: " +_permission);
			return -1;
		}	
	}

	public static void VideoOpen(String path)
	{
		mVideoPlayback.VideoPlayback_PlayVideo(path);
	}

	public static void VideoClose()
	{
		mVideoPlayback.VideoPlayback_Close();
	}

	public static boolean VideoDraw(ByteBuffer bytes)
	{
		return mVideoPlayback.VideoPlayback_WriteToBuffer(bytes) >= 0.5;
	}

	public static double VideoW()
	{
		return mVideoPlayback.VideoPlayback_VideoWidth();
	}

	public static double VideoH()
	{
		return mVideoPlayback.VideoPlayback_VideoHeight();
	}

	public static double VideoStatus()
	{
		return mVideoPlayback.VideoPlayback_Status();
	}

	public static void VideoSetVolume(double val)
	{
		mVideoPlayback.VideoPlayback_SetVolume(val);
	}
	
	//video playback second wave
	public static void VideoPause()
	{
		mVideoPlayback.VideoPlayback_Pause();
	}

	public static void VideoResume()
	{
		mVideoPlayback.VideoPlayback_Resume();
	}

	public static void VideoEnableLoop(double value)
	{
		mVideoPlayback.VideoPlayback_EnableLoop(value);
	}

	public static void VideoSeekTo(double value)
	{
		mVideoPlayback.VideoPlayback_SeekTo(value);
	}

	public static double VideoGetDuration()
	{
		return mVideoPlayback.VideoPlayback_GetDuration();
	}

	public static double VideoGetPosition()
	{
		return mVideoPlayback.VideoPlayback_GetPosition();
	}

	public static double VideoGetStatus()
	{
		return mVideoPlayback.VideoPlayback_GetStatus();
	}

	public static double VideoGetFormat()
	{
		return mVideoPlayback.VideoPlayback_GetFormat();
	}

	public static double VideoIsLooping()
	{
		return mVideoPlayback.VideoPlayback_VideoIsLooping();
	}

	public static double VideoGetVolume()
	{
		return mVideoPlayback.VideoPlayback_VideoGetVolume();
	}


	public static void RequestPermission(String _permission)
	{
		Log.i("yoyo","requesting permission:" +_permission);
		
		String[] array = _permission.split(",");
		
		if(array.length == 1)
		{
			ActivityCompat.requestPermissions(RunnerActivity.CurrentActivity, array,2296);
			return;
		}
		
		if(!(array[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") && (array[1].equals("android.permission.READ_EXTERNAL_STORAGE") || array[0].equals("android.permission.READ_EXTERNAL_STORAGE") && array[1].equals("android.permission.WRITE_EXTERNAL_STORAGE"))))
		{
			ActivityCompat.requestPermissions(RunnerActivity.CurrentActivity, array,2296);
			return;
		}
		
		//Storage....
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
		{
			try
			{
				Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
				intent.addCategory("android.intent.category.DEFAULT");
				intent.setData(Uri.parse(String.format("package:%s",RunnerActivity.CurrentActivity.getApplicationContext().getPackageName())));
				RunnerActivity.CurrentActivity.startActivityForResult(intent, 2296);
			} 
			catch (Exception e) 
			{
				Intent intent = new Intent();
				intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
				RunnerActivity.CurrentActivity.startActivityForResult(intent, 2296);
			}
		} 
		else
		{
			//below android 11
			if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
				ActivityCompat.requestPermissions(RunnerActivity.CurrentActivity, array,2296);
		}
	}

	public static Map<Integer, Pair<Long, Long>> s_MicPermReqMap = new HashMap<>();
	public static int s_MicPermReqId = 10000;

	public static void RequestMicPermission(long callback, long arg)
	{
		if (ContextCompat.checkSelfPermission(RunnerActivity.CurrentActivity, "android.permission.RECORD_AUDIO")
			== PackageManager.PERMISSION_GRANTED) {
			OnMicPermReqResult(true, callback, arg);
			return;
		}

		int requestId = s_MicPermReqId;
		++s_MicPermReqId;
		if (s_MicPermReqId == Integer.MAX_VALUE) {
    		s_MicPermReqId = 10000;
		}

		s_MicPermReqMap.put(requestId, new Pair<>(callback, arg));

		ActivityCompat.requestPermissions(
			RunnerActivity.CurrentActivity,
			new String[] { "android.permission.RECORD_AUDIO" },
			requestId
		);		
	}

	public static void ProcessMicPermReqResult(int requestCode, String[] permissions, int[] grantResults)
	{
		Pair<Long, Long> p = s_MicPermReqMap.remove(requestCode);
		if (p == null) {
			return;
		}

		boolean granted = grantResults != null 
					   && grantResults.length > 0
					   && grantResults[0] == PackageManager.PERMISSION_GRANTED;

		OnMicPermReqResult(granted, p.first, p.second);
	}

	public static boolean clipboardHasText()
	{
		boolean ret = false;
        ClipboardManager clipboard = mClipboard;
		if ((clipboard != null) && clipboard.hasPrimaryClip() && (clipboard.getPrimaryClip() != null)) {
			ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
			ret = (item != null) && (item.getText() != null) && (item.getText().length() > 0);
		} // end if
		return ret;
	}

	public static String clipboardGetText()
	{
		String ret = null;
        ClipboardManager clipboard = mClipboard;
		if ((clipboard != null) && clipboard.hasPrimaryClip() && (clipboard.getPrimaryClip() != null)) {
			ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
			if ((item != null) && (item.getText() != null)) {
				ret = item.getText().toString();
			} // end if
		} // end if
		return ret;
	}

	public static void clipboardSetText( String _text)
	{
        ClipboardManager clipboard = mClipboard;
		if (clipboard != null) {
			ClipData clip = ClipData.newPlainText( "gm", _text );
			clipboard.setPrimaryClip( clip );
		} // end if
	}

	
	@SuppressLint("MissingPermission") // permission will be added if GMS detects os_is_network_connected being used.
	public static boolean isNetworkConnected()
	{
        ConnectivityManager conMan = (ConnectivityManager) ms_context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(conMan!=null)
        {
			NetworkInfo activeNetwork = conMan.getActiveNetworkInfo();
			return (activeNetwork != null) && activeNetwork.isConnected();
		}
		return false;
	} // end isNetworkConnected

	public static void setSystemUIVisibilityFlags( int _flags)
	{
		final int flags = _flags;
		Log.i("yoyo","Calling setSystemUIVisibilityFlags");
		RunnerActivity.ViewHandler.post( new Runnable() {
			public void run(){
			
					RunnerActivity.UIVisibilityFlags = flags;
					RunnerActivity.CurrentActivity.setupUiVisibility();
					RunnerActivity.CurrentActivity.setupUiVisibilityDelayed();
			}
		});
		
	
	}

	public static void powersaveEnable( boolean _enable )
	{
		final boolean enable = _enable;
		RunnerActivity.ViewHandler.post( new Runnable() {
			public void run() {
				if (enable) {
					RunnerActivity.CurrentActivity.getWindow().clearFlags( android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON );
				} // end if
				else {
					RunnerActivity.CurrentActivity.getWindow().addFlags( android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON );
				} // end else
			}
		});
	} // end powersaveEnable

	public static void MoveTaskToBack()
	{
		RunnerActivity.CurrentActivity.runOnUiThread(new Runnable() {
	        @Override
	        public void run() {
				RunnerActivity.CurrentActivity.moveTaskToBack(true);
			}
		});
	}


	
	public static void cloudStringSave( String _data, String _desc, int _id )
	{
		
		Log.i("yoyo", "cloud_string_save() called when not logged in to appropriate service" );
		
	}
	
	public static void cloudSynchronise( int _id)
	{
		//Log.i("yoyo", "cloudSynchronise" );
		//RunnerActivity.wsSynchroniseFiles();
	
		
		Log.i("yoyo", "cloudSynchronise called when not logged in to appropriate service" );
		
	}

	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
    public static void DumpUsedMemory() {
    	Debug.MemoryInfo memoryInfo = new Debug.MemoryInfo();
		Debug.getMemoryInfo(memoryInfo);

		String memMessage = String.format(Locale.US,"App Memory: Pss=%.2f MB\nPrivate=%.2f MB\nShared=%.2f MB",
		memoryInfo.getTotalPss() / 1024.0,
		memoryInfo.getTotalPrivateDirty() / 1024.0,
		memoryInfo.getTotalSharedDirty() / 1024.0);

		Log.i( "yoyo", memMessage );
	} // end DumpUsedMemory

	
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static Context GetApplicationContext()
	{
		return ms_context;
	}

	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static int GamepadsCount()
	{
		return 0;
	}

	public static void ClearGamepads()
	{
	}

	public static boolean GamepadConnected(int deviceIndex)
	{
		return false;
	}

	public static String GamepadDescription(int deviceIndex)
	{
		return "";
	}

	public static float[] GamepadAxesValues(int deviceIndex)
	{
		return null;
	}

	public static float[] GamepadButtonValues(int deviceIndex)
	{
		return null;
	}

	public static int GamepadGMLMapping(int deviceIndex, int inputId)
	{
		return -1;
	}
	
	public static void PushLocalNotification( float fireTime, String title, String message, String data )
	{
	
		Object [] argArray = new Object[4];	
		argArray[0] = fireTime;
		argArray[1] = title;
		argArray[2] = message;
		argArray[3] = data;
	
		CallExtensionFunction("GooglePushNotificationsExtension","pushLocalNotification",4,argArray);
	
		//RunnerActivity.PushLocalNotification( fireTime, title, message, data );
	}

	public static int PushGetLocalNotification( int iIndex, int dsMap )
	{
		Object [] argArray = new Object[2];	
		argArray[0] = iIndex;
		argArray[1] = dsMap;
		
		Object ret = CallExtensionFunction("GooglePushNotificationsExtension","pushGetLocalNotification",2,argArray);
		
		if(ret!=null)
		{
			return (Integer)ret;
		}
		return -1;
	}
	
	public static int PushCancelLocalNotification( int iIndex )
	{	
		Object [] argArray = new Object[1];	
		argArray[0] = iIndex;
		
		Object ret = CallExtensionFunction("GooglePushNotificationsExtension","pushCancelLocalNotification",1,argArray);
		
		if(ret!=null)
		{
			return (Integer)ret;
		}
		return -1;
		
	}
	
	public static void RestrictOrientation(boolean _landscape,boolean _portrait,boolean _landscapeFlipped,boolean _portraitFlipped,boolean _fromPrefs)
	{
		RunnerActivity.CurrentActivity.RestrictOrientation(_landscape,_portrait,_landscapeFlipped,_portraitFlipped,_fromPrefs);
	} 
	
	
	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static String GetUDID()
	{
		// Just a warning: There is a known problem with using the following call for a certain class of devices
		// See: https://groups.google.com/forum/#!topic/android-developers/U4mOUI-rRPY
		// However, I'm inclined towards feeling that approaches to the issue such as
		// the one at http://appdreams.blogspot.co.uk/2010/12/android-and-unique-phone-id.html
		// are not adequate replacements to get a supposedly "secure" value and as 
		// such I'm sticking with what this gives you, consequences be damned
		String id = Secure.getString(ms_context.getContentResolver(), Secure.ANDROID_ID);
		if (id == null) {
			id = "UDID NOT AVAILABLE";
		}
		return id;
	}



	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------

	// Toggles the virtual keyboard on/off
	public static void VirtualKeyboardToggle(boolean _toggleOn, int _keyboardType, int _returnKeyType, int _autoCapitalizationType, 
											 boolean _predictiveTextEnabled, int[] _inputString)
	{
		RunnerKeyboardController controller = RunnerActivity.CurrentActivity.GetKeyboardController();
		if(controller != null)
		{
			controller.VirtualKeyboardToggle(_toggleOn, _keyboardType, _returnKeyType, _autoCapitalizationType, _predictiveTextEnabled, _inputString);
		}
	}

	// Returns the current cached status of the virtual keyboard
	public static boolean VirtualKeyboardGetStatus()
	{
		RunnerKeyboardController controller = RunnerActivity.CurrentActivity.GetKeyboardController();
		if(controller != null)
		{
			return controller.VirtualKeyboardGetStatus();
		}

		return false;
	}
	
	// Returns the cached virtual keyboard screen height
	public static int VirtualKeyboardGetHeight()
	{
		RunnerKeyboardController controller = RunnerActivity.CurrentActivity.GetKeyboardController();
		if(controller != null)
		{
			return controller.GetVirtualKeyboardHeightCached();
		}

		return 0;
	}

	// Called when the keyboard_string property is set in GMS
	public static void OnKeyboardStringSet(final int[] _newString)
	{
		RunnerActivity.ViewHandler.post( new Runnable() 
		{
			public void run() 
			{
				RunnerKeyboardController controller = RunnerActivity.CurrentActivity.GetKeyboardController();
				if(controller != null)
				{
					controller.OnKeyboardStringSet(_newString);
				}
			}
		});
	}

	// ----------------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------------
	public static void EnumerateGamepadDevices() {
		Gamepad.EnumerateDevices();
	}

	public static ByteBuffer[] EnumerateCertificates() throws Exception {
		ArrayList<ByteBuffer> certs = new ArrayList<ByteBuffer>();

		KeyStore keystore = KeyStore.getInstance("AndroidCAStore");
		keystore.load(null);

		Enumeration<String> aliases = keystore.aliases();
		while(aliases.hasMoreElements())
		{
			String alias = aliases.nextElement();
			Certificate cert = keystore.getCertificate(alias);

			if(cert.getType().equals("X.509"))
			{
				X509Certificate x509 = (X509Certificate)(cert);
				byte[] x509_der = x509.getEncoded();

				ByteBuffer buf = ByteBuffer.allocateDirect(x509_der.length);
				buf.put(x509_der, 0, x509_der.length);

				certs.add(buf);
			}
		}
		
		return certs.toArray(new ByteBuffer[0]);
	}
	
	private static WifiManager.MulticastLock multicast_lock = null;

	public static void AcquireMulticastLock() throws Exception {
		if (multicast_lock == null)
		{
			WifiManager wifi_manager = (WifiManager)(ms_context.getApplicationContext().getSystemService(Context.WIFI_SERVICE));

			multicast_lock = wifi_manager.createMulticastLock("RunnerJNILib");
			multicast_lock.setReferenceCounted(true);
		}

		multicast_lock.acquire();
	}

	public static void ReleaseMulticastLock() throws Exception {
		multicast_lock.release();
	}
}
